﻿$path = ".\scripts.html"
$txt = Get-Content -Raw -Encoding UTF8 $path

if ($txt -notmatch "if\s*\(\s*a\s*===\s*'lead_ganar'\s*\)") { throw "No encuentro el handler lead_ganar en scripts.html" }

# 1) Fix exacto del toast roto (string/template literal)
$txt2 = $txt -replace "toast\('LEADS',\s*✅ Convertido a cliente:\s*,\s*'ok'\);", "toast('LEADS', `✅ Convertido a cliente: `${res.clienteId}``, 'ok');"

# 2) Asegurar validación de id dentro del handler (si no existe ya)
if ($txt2 -notmatch "if\s*\(\s*!id\s*\)\s*\{\s*toast\('LEADS',\s*'Lead_ID vacio'") {
  $txt2 = $txt2 -replace "if\s*\(\s*a\s*===\s*'lead_ganar'\s*\)\s*\{", @"
if (a === 'lead_ganar'){
  if (!id){
    toast('LEADS', 'Lead_ID vacio', 'info');
    return;
  }
"@
}

Set-Content -Encoding UTF8 $path $txt2
Write-Host "OK: scripts.html fixed lead_ganar toast + id guard"
