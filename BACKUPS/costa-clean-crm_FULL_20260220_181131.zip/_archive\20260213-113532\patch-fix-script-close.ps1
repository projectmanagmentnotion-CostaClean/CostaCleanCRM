﻿$path = "scripts.html"
$txt  = Get-Content -Raw -Encoding UTF8 $path

# 1) Si existe "});</script>" dentro del JS, lo convertimos a "});" + salto (el </script> debe estar fuera)
$txt = [regex]::Replace($txt, "\}\);\s*</script>", "});`r`n", 1)

# 2) Si quedaron cierres duplicados seguidos, los reducimos a uno
$txt = [regex]::Replace($txt, "(</script>\s*){2,}", "</script>`r`n")

Set-Content -Path $path -Value $txt -Encoding UTF8
Write-Host "OK: scripts.html reparado (</script> fuera del JS, sin duplicados)" -ForegroundColor Green
