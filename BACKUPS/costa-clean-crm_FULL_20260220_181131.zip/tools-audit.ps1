﻿$ErrorActionPreference = "Continue"

# carpeta audit con timestamp
$ts = Get-Date -Format "yyyyMMdd-HHmmss"
$root = Join-Path (Get-Location) "audit\$ts"
New-Item -ItemType Directory -Force -Path $root | Out-Null

function Save-Text($name, $text){
  $p = Join-Path $root $name
  $text | Out-File -FilePath $p -Encoding UTF8
}

function Run-Cmd($name, $cmd){
  $p = Join-Path $root $name
  $out = & powershell -NoProfile -Command $cmd 2>&1
  $out | Out-File -FilePath $p -Encoding UTF8
}

# 1) Info repo
Run-Cmd "01_git_status.txt" "git status -sb; '' ; git status --porcelain"
Run-Cmd "02_git_last_commit.txt" "git log -1 --oneline --decorate; '' ; git show -1 --name-only --oneline"
Run-Cmd "03_git_remotes.txt" "git remote -v"
Run-Cmd "04_git_branch.txt" "git branch -vv"

# 2) Info clasp
Run-Cmd "10_clasp_status.txt" "clasp status"
Run-Cmd "11_clasp_settings.txt" "Get-Content .\.clasp.json"
Run-Cmd "12_claspignore.txt" "if(Test-Path .\.claspignore){ Get-Content .\.claspignore } else { 'NO .claspignore' }"

# 3) Sanidad scripts.html
Run-Cmd "20_scripts_script_tags.txt" "rg -n '</script>|<script' .\scripts.html"
Run-Cmd "21_mock_flags.txt" "rg -n 'state\.useMock|applyMockFromUrl_|loadMockPreference_|__forceRealFromUrl_' .\scripts.html"

# 4) Extraer JS del <script> y hacer check de sintaxis con Node (SIN abrir navegador)
$extractPath = Join-Path $root "_scripts_extracted.js"
try{
  $html = Get-Content -Raw -Encoding UTF8 .\scripts.html
  $m = [regex]::Match($html, '<script[^>]*>([\s\S]*?)</script>', 'IgnoreCase')
  if(-not $m.Success){ throw "No <script> encontrado en scripts.html" }
  $m.Groups[1].Value | Out-File -FilePath $extractPath -Encoding UTF8
  Run-Cmd "22_node_check.txt" "node --check `"$extractPath`""
}catch{
  Save-Text "22_node_check.txt" ("ERROR extracting/checking script: " + $_.Exception.Message)
}

# 5) Auditar endpoints/servidor
Run-Cmd "30_callServer_usage.txt" "rg -n 'callServer\(' .\scripts.html"
Run-Cmd "31_webapp_api_exports.txt" "rg -n 'function\s+doGet|function\s+doPost|api' .\WEBAPP_API.js .\Code.js .\API.js"

# 6) Resumen corto
$summary = @()
$summary += "AUDIT ROOT: $root"
$summary += ""
$summary += "FILES:"
$summary += (Get-ChildItem $root | Select-Object Name,Length | Format-Table -AutoSize | Out-String)

# quick grep: ¿está forzando mock?
$mockHit = (Select-String -Path .\scripts.html -Pattern "state\.useMock\s*=\s*true" -SimpleMatch -ErrorAction SilentlyContinue)
$summary += ""
$summary += ("MOCK ASSIGNMENTS: " + ($(if($mockHit){ $mockHit.Count } else { 0 })))

$summary | Out-File (Join-Path $root "00_SUMMARY.txt") -Encoding UTF8

Write-Host "OK: auditoria generada en: $root" -ForegroundColor Green
Write-Host "Pégame SOLO el contenido de: audit\$ts\00_SUMMARY.txt y 22_node_check.txt" -ForegroundColor Yellow
