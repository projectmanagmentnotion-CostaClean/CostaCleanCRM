﻿param(
  [int]$Minutes = 120,
  [switch]$RunTests = $true
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# --- Paths (sin backslashes embebidos) ---
$root = (Get-Location).Path
$diagRoot = Join-Path $root "_diagnostics"
$diagDir  = Join-Path $diagRoot "runlogs"
New-Item -ItemType Directory -Force $diagDir | Out-Null

$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$runOut  = Join-Path $diagDir ("run_" + $ts + ".txt")
$logsOut = Join-Path $diagDir ("clasp_logs_" + $ts + ".txt")
$metaOut = Join-Path $diagDir ("meta_" + $ts + ".txt")

# --- Writer robusto (evita Tee-Object/Out-File) ---
$utf8 = New-Object System.Text.UTF8Encoding($false) # no BOM

function AppendLine([string]$file, [string]$text){
  [System.IO.File]::AppendAllText($file, $text + [Environment]::NewLine, $utf8)
}

function Log([string]$text){
  AppendLine $metaOut $text
  Write-Host $text
}

function SaveText([string]$file, $lines){
  # $lines puede ser string o array; normalizamos
  if ($null -eq $lines) { $lines = "" }
  if ($lines -is [string]) {
    [System.IO.File]::WriteAllText($file, $lines + [Environment]::NewLine, $utf8)
  } else {
    [System.IO.File]::WriteAllLines($file, $lines, $utf8)
  }
}

Log "=== CostaClean CRM | Clasp Run+Logs Dump ==="
Log ("TS=" + $ts)
Log ("PWD=" + $root)
Log ("OUT_META=" + $metaOut)
Log ("OUT_RUN =" + $runOut)
Log ("OUT_LOGS=" + $logsOut)
Log ""

# --- Basic info ---
Log "## clasp version"
try {
  $v = & clasp -v 2>&1
  foreach($l in $v){ AppendLine $metaOut $l }
} catch {
  Log ("ERROR: clasp -v => " + $_.Exception.Message)
}

Log ""
Log "## clasp status"
try {
  $st = & clasp status 2>&1
  foreach($l in $st){ AppendLine $metaOut $l }
} catch {
  Log ("ERROR: clasp status => " + $_.Exception.Message)
}

# --- Optional: run tests ---
if($RunTests){
  Log ""
  Log "## Running tests (clasp run...)"

  $tests = @(
    "__test_apiPing",
    "__test_apiDbInfo",
    "__test_apiDashboard",
    "__test_apiListClientes",
    "__test_apiListLeads",
    "__test_apiListPresupuestos",
    "__test_apiListFacturas_5",
    "__test_apiGetPresupuesto_PRO_2025_0019"
  )

  SaveText $runOut ("=== RUN TESTS " + $ts + " ===")

  foreach($t in $tests){
    AppendLine $runOut ""
    AppendLine $runOut ("--- RUN: " + $t + " ---")
    try{
      $out = & clasp run $t 2>&1
      foreach($l in $out){ AppendLine $runOut $l }
    } catch {
      AppendLine $runOut ("ERROR running " + $t + ": " + $_.Exception.Message)
    }
  }

  AppendLine $runOut ""
  AppendLine $runOut ("=== DONE TESTS " + $ts + " ===")
  Log ("Saved run output: " + $runOut)
}

# --- Fetch logs (probamos variantes) ---
Log ""
Log ("## Fetching clasp logs for last " + $Minutes + " minutes")

$logCommands = @(
  @("logs","--json","--since",($Minutes.ToString()+"m")),
  @("logs","--since",($Minutes.ToString()+"m")),
  @("logs","--json"),
  @("logs")
)

$got = $false
foreach($args in $logCommands){
  if($got){ break }
  $cmd = "clasp " + ($args -join " ")
  Log ("Trying: " + $cmd)

  try{
    $res = & clasp @args 2>&1
    if($res -and $res.Count -gt 0){
      SaveText $logsOut $res
      Log ("OK logs saved: " + $logsOut)
      $got = $true
    } else {
      Log "No output from this logs command."
    }
  } catch {
    Log ("FAILED: " + $cmd + " => " + $_.Exception.Message)
  }
}

if(-not $got){
  Log "ERROR: Could not fetch logs with any clasp logs variant."
}

# --- ZIP bundle ---
Log ""
$zipPath = Join-Path $diagDir ("bundle_" + $ts + ".zip")
$files = @()
if(Test-Path $metaOut){ $files += $metaOut }
if(Test-Path $runOut){  $files += $runOut }
if(Test-Path $logsOut){ $files += $logsOut }

if($files.Count -gt 0){
  if(Test-Path $zipPath){ Remove-Item -Force $zipPath }
  Compress-Archive -Path $files -DestinationPath $zipPath -Force
  Log ("ZIP created: " + $zipPath)
} else {
  Log "No files to zip."
}

Log ""
Log "=== DONE ==="
