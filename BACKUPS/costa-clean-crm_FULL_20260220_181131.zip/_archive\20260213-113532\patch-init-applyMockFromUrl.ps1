﻿$path = "scripts.html"
$txt = Get-Content -Raw -Encoding UTF8 $path

$rx  = "document\.addEventListener\('DOMContentLoaded',\s*\(\)\s*=>\s*\{\s*\r?\n"
$rep = "document.addEventListener('DOMContentLoaded', () => {`r`n  applyMockFromUrl_();`r`n"

if($txt -notmatch $rx){ throw "No encontré el bloque DOMContentLoaded para insertar applyMockFromUrl_()" }

$txt2 = [regex]::Replace($txt, $rx, $rep, 1)
Set-Content -Encoding UTF8 -Path $path -Value $txt2

Write-Host "OK: insertado applyMockFromUrl_() en DOMContentLoaded" -ForegroundColor Green
