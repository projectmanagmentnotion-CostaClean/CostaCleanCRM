﻿$path = "scripts.html"
$txt  = Get-Content -Raw -Encoding UTF8 $path

# Insertar helper debug panel si no existe
if($txt -notmatch "__ensureDebugPanel_"){
  $insertAfter = "function __installGlobalErrorCatcher_\(\)\s*\{"
  $m = [regex]::Match($txt, $insertAfter)
  if(-not $m.Success){ throw "No encontré function __installGlobalErrorCatcher_() para insertar debug panel." }

  $helper = @"
function __ensureDebugPanel_(){
  try{
    if(document.getElementById('cc-debug-panel')) return;
    const d = document.createElement('div');
    d.id = 'cc-debug-panel';
    d.style.position = 'fixed';
    d.style.bottom = '12px';
    d.style.left = '12px';
    d.style.zIndex = '999999';
    d.style.maxWidth = '92vw';
    d.style.padding = '8px 10px';
    d.style.borderRadius = '10px';
    d.style.background = 'rgba(0,0,0,0.82)';
    d.style.color = '#fff';
    d.style.fontSize = '12px';
    d.style.fontFamily = 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace';
    d.style.whiteSpace = 'pre-wrap';
    d.style.display = 'none';
    d.textContent = 'DEBUG PANEL';
    document.body.appendChild(d);
  }catch(_){}
}
function __debugShow_(title, msg){
  try{
    __ensureDebugPanel_();
    const d = document.getElementById('cc-debug-panel');
    if(!d) return;
    d.style.display = 'block';
    d.textContent = '[' + title + '] ' + String(msg);
  }catch(_){}
}

"@

  # Colocar helper antes del __installGlobalErrorCatcher_ (para que exista)
  $txt = $helper + $txt
}

# Dentro de __installGlobalErrorCatcher_ añadir hooks a window.onerror y unhandledrejection si no están usando debug
if($txt -notmatch "__debugShow_\('JS ERROR'"){
  $txt = [regex]::Replace($txt,
    "function __installGlobalErrorCatcher_\(\)\s*\{",
    "function __installGlobalErrorCatcher_(){`r`n  try{ __ensureDebugPanel_(); }catch(_){}`r`n",
    1
  )

  # agregar listeners al final de la función (antes del cierre })
  $txt = [regex]::Replace($txt,
    "(\r?\n\})\s*(\r?\n\r?\n)document\.addEventListener\('DOMContentLoaded'",
@"
  try{
    window.addEventListener('error', (ev) => {
      const m = (ev && ev.message) ? ev.message : 'unknown error';
      __debugShow_('JS ERROR', m);
    });
    window.addEventListener('unhandledrejection', (ev) => {
      const r = ev && ev.reason ? ev.reason : '';
      const m = (r && r.message) ? r.message : String(r);
      __debugShow_('PROMISE', m);
    });
  }catch(_){}
$1$2document.addEventListener('DOMContentLoaded'
"@,
    1
  )
}

Set-Content -Path $path -Value $txt -Encoding UTF8
Write-Host "OK: debug panel + capturador de errores insertado" -ForegroundColor Green
