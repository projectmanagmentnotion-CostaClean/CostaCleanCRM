﻿$path = "scripts.html"
$txt  = Get-Content -Raw -Encoding UTF8 $path

# Match DOMContentLoaded block (singleline)
$rx = "document\.addEventListener\('DOMContentLoaded',\s*\(\)\s*=>\s*\{.*?\}\);\s*"
$re = [regex]::new($rx, [System.Text.RegularExpressions.RegexOptions]::Singleline)
if (-not $re.IsMatch($txt)) { throw "No encontré el bloque document.addEventListener('DOMContentLoaded'...) para parchear." }

# Replacement JS (line-by-line) -> join with newlines
$rep = @(
  "document.addEventListener('DOMContentLoaded', () => {"
  "  __installGlobalErrorCatcher_();"
  ""
  "  // mock/real (storage -> url -> force real)"
  "  try { loadMockPreference_(); } catch(e){ try{ toast('Init', 'loadMockPreference: ' + ((e&&e.message)?e.message:String(e)), 'error'); }catch(_){ } }"
  "  try { applyMockFromUrl_(); } catch(e){ try{ toast('Init', 'applyMockFromUrl: ' + ((e&&e.message)?e.message:String(e)), 'error'); }catch(_){ } }"
  "  try { __forceRealFromUrl_(); } catch(e){ try{ toast('Init', '__forceRealFromUrl: ' + ((e&&e.message)?e.message:String(e)), 'error'); }catch(_){ } }"
  ""
  "  // UI primero (blindado)"
  "  try { initNav(); } catch(e){ try{ toast('Init', 'initNav: ' + ((e&&e.message)?e.message:String(e)), 'error'); }catch(_){ } }"
  "  try { initListTabs(); } catch(e){ try{ toast('Init', 'initListTabs: ' + ((e&&e.message)?e.message:String(e)), 'error'); }catch(_){ } }"
  "  try { updateMockChip_(); } catch(e){}"
  ""
  "  // estado inicial"
  "  try { showScreen('screen-home'); } catch(e){}"
  "  try { setNavActive('home'); } catch(e){}"
  ""
  "  // toast diagnóstico"
  "  try { toast('Init', 'OK · mode=' + (state && state.useMock ? 'mock' : 'real'), 'info'); } catch(_){ }"
  ""
  "  // dashboard al final y protegido"
  "  try { loadDashboard(); } catch(e){ try{ toast('Dashboard', (e && e.message) ? e.message : String(e), 'error'); }catch(_){ } }"
  "});"
) -join "`n"

$txt2 = $re.Replace($txt, $rep, 1)
Set-Content -Path $path -Value $txt2 -Encoding UTF8
Write-Host "OK: DOMContentLoaded blindado + toast diagnóstico aplicado" -ForegroundColor Green
