﻿$path = ".\scripts.html"
$txt = Get-Content -Raw -Encoding UTF8 $path

$bad = "toast('LEADS', ✅ Convertido a cliente: `${res.clienteId}``, 'ok');"
if ($txt -notmatch [regex]::Escape($bad)) {
  throw "No encontré la línea exacta rota. Pásame el bloque de 10 líneas alrededor del toast y lo ajusto."
}

$good = "toast('LEADS', `✅ Convertido a cliente: `${res.clienteId}``, 'ok');"

$txt2 = $txt -replace [regex]::Escape($bad), $good

Set-Content -Encoding UTF8 $path $txt2
Write-Host "OK: scripts.html fixed toast template literal"
