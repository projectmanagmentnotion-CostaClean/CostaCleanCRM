﻿$path = "scripts.html"
$txt  = Get-Content -Raw -Encoding UTF8 $path

$old = "(?s)document\.addEventListener\('DOMContentLoaded',\s*\(\)\s*=>\s*\{.*?\}\);\s*<\/script>"
if ($txt -notmatch $old) { throw "No encontré el bloque DOMContentLoaded esperado en scripts.html" }

$new = @"
document.addEventListener('DOMContentLoaded', () => {
  __installGlobalErrorCatcher_();

  // 1) Base desde storage
  loadMockPreference_();

  // 2) Override por URL (?mock=0 / ?mock=1) — prioridad máxima
  applyMockFromUrl_();

  // 3) Compat/override adicional (si existe)
  __forceRealFromUrl_();

  updateMockChip_();
  loadDashboard();
  initNav();
  initListTabs();

  // estado inicial
  showScreen('screen-home');
  setNavActive('home');
});

</script>
"@

$txt2 = [regex]::Replace($txt, $old, $new, 1)
Set-Content -Path $path -Value $txt2 -Encoding UTF8
Write-Host "OK: reorder init (mock/url/storage) aplicado" -ForegroundColor Green
