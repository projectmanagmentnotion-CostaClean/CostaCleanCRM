﻿$ErrorActionPreference = "Stop"
$path = Join-Path (Get-Location) "scripts.html"
$txt = Get-Content -Raw -Encoding UTF8 $path

# 1) Arreglar pegado: "}function setListState"
$txt = $txt -replace "\}\s*function\s+setListState", "}`r`n`r`nfunction setListState"

# 2) Arreglar pegado: "}/* =========================" (quedó así después del dashboard)
$txt = $txt -replace "\}\s*/\*\s*========================", "}`r`n`r`n/* ========================="

# 3) Fix loadEntityDetail: usa raw + normalizeApiItem_ y elimina 'res' undefined
$pattern = "(?s)async function loadEntityDetail\(entity, id\)\{.*?\n\s*try \{\s*\n\s*const raw = await callServer\('apiGet', entity, id\);\s*\n\s*safeLog_\(.*?\);\s*\n\s*const view = mapEntityDetail_\(entity, res\);\s*"
if($txt -match $pattern){
  $replacement = @"
async function loadEntityDetail(entity, id){
  showScreen('screen-detalle');
  setDetailState('loading', 'Cargando detalle...');
  try {
    const raw = await callServer('apiGet', entity, id);
    const res = normalizeApiItem_(raw);
    safeLog_('apiGet '+entity, res);
    const view = mapEntityDetail_(entity, res);
"@
  $txt = [regex]::Replace($txt, $pattern, $replacement, 1)
}else{
  # fallback: reemplazos más directos si el bloque no matchea exacto
  $txt = $txt -replace "safeLog_\('fetchEntityList\s*\+entity'\s*,\s*res\)\s*;", "const res = normalizeApiItem_(raw);`r`n    safeLog_('apiGet '+entity, res);"
  $txt = $txt -replace "const view = mapEntityDetail_\(entity,\s*res\);", "const view = mapEntityDetail_(entity, res);"
}

Set-Content -Encoding UTF8 $path $txt
Write-Host "OK: scripts.html fixed (newline + loadEntityDetail)" -ForegroundColor Green
