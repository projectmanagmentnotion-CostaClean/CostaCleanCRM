﻿$path = ".\scripts.html"
$txt = Get-Content -Raw -Encoding UTF8 $path

# 1) Fix toast inválido (emoji fuera de comillas/template literal)
$txt2 = $txt -replace "toast\('LEADS',\s*✅ Convertido a cliente:\s*,\s*'ok'\);", "toast('LEADS', ``✅ Convertido a cliente: `${res.clienteId}``, 'ok');"

# 2) Fix pegote: "}google.script.run" => "}\n    google.script.run"
$txt2 = $txt2 -replace "(\}\s*)google\.script\.run", "`$1`n    google.script.run"

if ($txt2 -eq $txt) {
  Write-Host "WARN: No hubo cambios (no encontré patrón exacto). Igual guardo por seguridad."
}

Set-Content -Encoding UTF8 $path $txt2
Write-Host "OK: scripts.html parcheado (toast + newline google.script.run)"
