﻿$ErrorActionPreference = "Stop"

$path = Join-Path (Get-Location) "scripts.html"
if(!(Test-Path $path)){ throw "No existe scripts.html en $(Get-Location)" }

$txt = Get-Content -Raw -Encoding UTF8 $path

# 1) Insertar normalizers después de joinParts_ si no existen
if($txt -notmatch "function\s+normalizeApiList_"){
  $insert = @"
 
// Normaliza respuestas del server:
// - [ ... ]                               => items
// - { items:[...]}                        => items
// - { data:{ items:[...]} }               => items
// - { ok:true, items:[...]}               => items
// - { ok:true, data:[...]}                => items
// - { ok:true, item:{...} }               => item (ver normalizeApiItem_)
function normalizeApiList_(res){
  if (!res) return [];
  if (Array.isArray(res)) return res;
  if (Array.isArray(res.items)) return res.items;
  if (Array.isArray(res.data)) return res.data;
  if (res.data && Array.isArray(res.data.items)) return res.data.items;
  if (res.result && Array.isArray(res.result.items)) return res.result.items;
  return [];
}

function normalizeApiItem_(res){
  if (!res) return null;
  if (res.item && typeof res.item === 'object') return res.item;
  if (res.data && typeof res.data === 'object' && !Array.isArray(res.data)) return res.data;
  if (res.result && typeof res.result === 'object') return res.result;
  if (typeof res === 'object' && !Array.isArray(res)) return res;
  return null;
}
"@

  $pattern = "(?s)(function\s+joinParts_\s*\(\s*parts\s*\)\s*\{\s*.*?\}\s*)"
  $m = [regex]::Match($txt, $pattern)
  if(!$m.Success){ throw "No pude localizar la función joinParts_() para insertar normalizers." }

  $txt = [regex]::Replace($txt, $pattern, ('$1' + $insert), 1)
}

# 2) Reemplazar loadDashboard() mock por versión real (async)
$dashPattern = "(?s)/\*\s*========================\s*DASHBOARD\s*\(mock simple\)\s*========================\s*\*/\s*function\s+loadDashboard\s*\(\s*\)\s*\{.*?\}\s*"
$m2 = [regex]::Match($txt, $dashPattern)
if(!$m2.Success){
  # fallback: si el comentario cambió, matchea por la función
  $dashPattern = "(?s)function\s+loadDashboard\s*\(\s*\)\s*\{.*?\}\s*"
  $m2 = [regex]::Match($txt, $dashPattern)
  if(!$m2.Success){ throw "No pude localizar el bloque loadDashboard() para reemplazar." }
}

$dashReplacement = @"
/* =========================
   DASHBOARD (real)
 ========================= */
async function loadDashboard(){
  // Default UI mientras carga
  if (qs('#kpiVentasMes')) qs('#kpiVentasMes').textContent = '';
  if (qs('#kpiCobrado')) qs('#kpiCobrado').textContent = '';
  if (qs('#kpiPendiente')) qs('#kpiPendiente').textContent = '';

  if (qs('#kpiFactPendientes')) qs('#kpiFactPendientes').textContent = '';
  if (qs('#kpiFactPendientesSub')) qs('#kpiFactPendientesSub').textContent = '';

  if (qs('#kpiIvaNeto')) qs('#kpiIvaNeto').textContent = '';
  if (qs('#kpiRepercutido')) qs('#kpiRepercutido').textContent = '';
  if (qs('#kpiSoportado')) qs('#kpiSoportado').textContent = '';

  if (qs('#kpiGastoDeducible')) qs('#kpiGastoDeducible').textContent = '';
  if (qs('#kpiCompras')) qs('#kpiCompras').textContent = '';
  if (qs('#kpiOperacion')) qs('#kpiOperacion').textContent = '';

  // Si estás en mock, no llamamos server
  if (state && state.useMock) return;

  try{
    const raw = await callServer('apiDashboard'); // period opcional
    const d = normalizeApiItem_(raw) || {};

    const ventasMes    = toNumber_(pickValue_(d, ['ventasMes','ventas_mes','ventas']));
    const cobradoMes   = toNumber_(pickValue_(d, ['cobradoMes','cobrado','cobrado_mes']));
    const pendienteMes = toNumber_(pickValue_(d, ['pendienteMes','pendiente','pendiente_mes']));

    const factPendCount = pickValue_(d, ['facturasPendientes','factPendientes','pendientesCount','countPendientes']);
    const factPendAmt   = toNumber_(pickValue_(d, ['facturasPendientesTotal','factPendientesTotal','pendientesTotal','totalPendiente']));

    const ivaNeto     = toNumber_(pickValue_(d, ['ivaNetoTrimestre','ivaNeto','iva_neto']));
    const repercutido = toNumber_(pickValue_(d, ['ivaRepercutido','repercutido','iva_repercutido']));
    const soportado   = toNumber_(pickValue_(d, ['ivaSoportado','soportado','iva_soportado']));

    const gastoDed    = toNumber_(pickValue_(d, ['gastoDeducibleTrimestre','gastoDeducible','gasto_deducible']));
    const comprasTri  = toNumber_(pickValue_(d, ['comprasTrimestre','compras','compras_tri']));
    const operacionTri= toNumber_(pickValue_(d, ['operacionTrimestre','operacion','operacion_tri']));

    if (qs('#kpiVentasMes')) qs('#kpiVentasMes').textContent = (ventasMes!=null ? formatMoney(ventasMes) : '');
    if (qs('#kpiCobrado')) qs('#kpiCobrado').textContent = (cobradoMes!=null ? formatMoney(cobradoMes) : '');
    if (qs('#kpiPendiente')) qs('#kpiPendiente').textContent = (pendienteMes!=null ? formatMoney(pendienteMes) : '');

    if (qs('#kpiFactPendientes')) qs('#kpiFactPendientes').textContent = (factPendCount!=='' && factPendCount!=null ? String(factPendCount) : '');
    if (qs('#kpiFactPendientesSub')) qs('#kpiFactPendientesSub').textContent = (factPendAmt!=null ? formatMoney(factPendAmt) : '');

    if (qs('#kpiIvaNeto')) qs('#kpiIvaNeto').textContent = (ivaNeto!=null ? formatMoney(ivaNeto) : '');
    if (qs('#kpiRepercutido')) qs('#kpiRepercutido').textContent = (repercutido!=null ? formatMoney(repercutido) : '');
    if (qs('#kpiSoportado')) qs('#kpiSoportado').textContent = (soportado!=null ? formatMoney(soportado) : '');

    if (qs('#kpiGastoDeducible')) qs('#kpiGastoDeducible').textContent = (gastoDed!=null ? formatMoney(gastoDed) : '');
    if (qs('#kpiCompras')) qs('#kpiCompras').textContent = (comprasTri!=null ? formatMoney(comprasTri) : '');
    if (qs('#kpiOperacion')) qs('#kpiOperacion').textContent = (operacionTri!=null ? formatMoney(operacionTri) : '');
  }catch(e){
    console.error(e);
    try{ toast('Dashboard', e?.message ? e.message : String(e), 'error'); }catch(_){}
  }
}
"@

$txt = [regex]::Replace($txt, $dashPattern, $dashReplacement, 1)

# 3) fetchEntityList: raw -> normalizeApiList_
$txt = $txt -replace "let\s+items\s*=\s*\[\]\s*;", "let raw = null;"
$txt = $txt -replace "items\s*=\s*await\s*callServer\('apiListClientes'", "raw = await callServer('apiListClientes'"
$txt = $txt -replace "items\s*=\s*await\s*callServer\('apiListLeads'", "raw = await callServer('apiListLeads'"
$txt = $txt -replace "items\s*=\s*await\s*callServer\('apiList'\s*,\s*entity", "raw = await callServer('apiList', entity"

if($txt -notmatch "const\s+items\s*=\s*normalizeApiList_\(raw\)"){
  $txt = $txt -replace "\r?\n\s*let\s+rows\s*=\s*\(Array\.isArray\(items\)\s*\?\s*items\s*:\s*\[\]\)\.map", "`n    const items = normalizeApiList_(raw);`n    let rows = items.map"
}

# 4) loadEntityDetail: raw -> normalizeApiItem_
$txt = $txt -replace "const\s+res\s*=\s*await\s+callServer\('apiGet'\s*,\s*entity\s*,\s*id\)\s*;", "const raw = await callServer('apiGet', entity, id);"
$txt = $txt -replace "safeLog_\('fetchEntityList\s*\+entity'\s*,\s*res\)\s*;\s*\r?\n\s*const\s+view\s*=\s*mapEntityDetail_\(entity\s*,\s*res\)\s*;", "const res = normalizeApiItem_(raw);`n    safeLog_('apiGet '+entity, res);`n    const view = mapEntityDetail_(entity, res);"

# Guardar
Set-Content -Encoding UTF8 $path $txt

Write-Host "OK: scripts.html parcheado (normalizers + dashboard real + normalize list/get)" -ForegroundColor Green
