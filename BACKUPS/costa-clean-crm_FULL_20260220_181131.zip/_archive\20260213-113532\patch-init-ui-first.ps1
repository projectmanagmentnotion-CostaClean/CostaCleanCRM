﻿$path = "scripts.html"
$lines = Get-Content -Encoding UTF8 $path

# 1) localizar inicio del handler DOMContentLoaded
$start = $null
for($i=1; $i -le $lines.Count; $i++){
  if($lines[$i-1] -like "*document.addEventListener('DOMContentLoaded'*"){
    $start = $i
    break
  }
}
if(-not $start){ throw "No encontré document.addEventListener('DOMContentLoaded' en scripts.html" }

# 2) localizar fin del handler: primera línea que sea '});' después del start
$end = $null
for($i=$start; $i -le $lines.Count; $i++){
  if($lines[$i-1] -match "^\s*\}\);\s*$"){
    $end = $i
    break
  }
}
if(-not $end){ throw "No encontré el cierre '});' del DOMContentLoaded (desde línea $start)" }

# 3) nuevo handler (UI primero, dashboard protegido)
$rep = @(
"document.addEventListener('DOMContentLoaded', () => {",
"  __installGlobalErrorCatcher_();",
"",
"  // mock/real (storage -> url -> force real)",
"  loadMockPreference_();",
"  applyMockFromUrl_();",
"  __forceRealFromUrl_();",
"",
"  // UI primero: que los botones funcionen aunque dashboard falle",
"  initNav();",
"  initListTabs();",
"  updateMockChip_();",
"",
"  // estado inicial",
"  showScreen('screen-home');",
"  setNavActive('home');",
"",
"  // dashboard al final y protegido",
"  try {",
"    loadDashboard();",
"  } catch (e) {",
"    try { toast('Init', (e && e.message) ? e.message : String(e), 'error'); } catch(_) {}",
"  }",
"});"
)

$before = @()
if($start -gt 1){ $before = $lines[0..($start-2)] }

$after = @()
if($end -lt $lines.Count){ $after = $lines[$end..($lines.Count-1)] }

$newLines = $before + $rep + $after
Set-Content -Path $path -Value $newLines -Encoding UTF8

Write-Host ("OK: init reorder aplicado. Reemplacé líneas {0}..{1}" -f $start, $end) -ForegroundColor Green
