﻿/* =========================
   ARCHIVO: scripts.html
   Lógica UI (mock) + router de acciones + listas + detalle
========================= */

/* === CC JS FINGERPRINT (v324) === */
(function(){
  try{
    var add = function(){
      try{
        if(document.getElementById('cc-js-fingerprint')) return;
        var d = document.createElement('div');
        d.id = 'cc-js-fingerprint';
        d.style.position = 'fixed';
        d.style.bottom = '10px';
        d.style.right = '10px';
        d.style.zIndex = '2147483647';
        d.style.padding = '6px 10px';
        d.style.borderRadius = '10px';
        d.style.background = 'rgba(0,0,0,.72)';
        d.style.border = '1px solid rgba(255,255,255,.12)';
        d.style.color = '#fff';
        d.style.font = '12px/1.25 system-ui, -apple-system, Segoe UI, Roboto, Arial';
        d.textContent = 'JS OK · search=' + (location && location.search ? location.search : '') +
                      ' | href=' + (location && location.href ? location.href : '') +
                      ' | ref=' + (document && document.referrer ? document.referrer : '');
        (document.body || document.documentElement).appendChild(d);
      }catch(_){ }
    };
    if(document.readyState === 'loading'){
      document.addEventListener('DOMContentLoaded', add);
      setTimeout(add, 1500);
    }else{
      add();
      setTimeout(add, 1500);
    }
  }catch(_){ }
})();

// ==========================
// Helpers DOM
const qs  = (sel, root=document) => root.querySelector(sel);
const qsa = (sel, root=document) => Array.from(root.querySelectorAll(sel));

// =========================
// Estado UI
const env = (() => {
  try {
    const sp = new URLSearchParams(location.search || '');
    const debug = ['1','true'].includes(String(sp.get('debug')).toLowerCase());
    const mock  = ['1','true'].includes(String(sp.get('mock')).toLowerCase());
    return { debug, mock, dev: debug || mock };
  } catch (_) {
    return { debug:false, mock:false, dev:false };
  }
})();

const state = {
  useMock: false,
  currentEntity: 'clientes',
  listFilterClientId: null,
  detail: { entity:null, id:null, clientId:null },
  lastScreen: 'screen-home'
};

const STORAGE_KEYS = {
  useMock: 'cc_use_mock',
  legacyUseMock: 'cc_useMock'
};

const store = {
  presupuestos: [],
  presDetalle: {},
  clientes: [],
  leads: []
};

/* === CC DEBUG CORE (v328 PRO CLEAN) === */
function isDebugEnabled_(){
  try{
    if (typeof window !== 'undefined' && window.__CC_DEBUG__ !== null && typeof window.__CC_DEBUG__ !== 'undefined'){
      try{ localStorage.setItem('cc_debug', window.__CC_DEBUG__ === true ? '1' : '0'); }catch(_){ }
    }
    try{ return localStorage.getItem('cc_debug') === '1'; }catch(_){ }
  }catch(_){ }
  return false;
}
function __ensureDebugPanel_(){
  try{
    if (!isDebugEnabled_()) return;
    if(document.getElementById('cc-debug-panel')) return;
    const d = document.createElement('div');
    d.id = 'cc-debug-panel';
    d.style.position = 'fixed';
    d.style.bottom = '12px';
    d.style.left = '12px';
    d.style.zIndex = '999999';
    d.style.maxWidth = '92vw';
    d.style.padding = '8px 10px';
    d.style.borderRadius = '10px';
    d.style.background = 'rgba(0,0,0,0.82)';
    d.style.color = '#fff';
    d.style.fontSize = '12px';
    d.style.fontFamily = 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace';
    d.style.whiteSpace = 'pre-wrap';
    d.style.display = 'none';
    d.textContent = 'DEBUG PANEL';
    document.body.appendChild(d);
  }catch(_){ }
}
function __debugShow_(title, msg){
  try{
    __ensureDebugPanel_();
    const d = document.getElementById('cc-debug-panel');
    if(!d) return;
    d.style.display = 'block';
    d.textContent = '[' + title + '] ' + String(msg);
  }catch(_){ }
}
function safeLog_(label, obj){
  try{
    if (typeof console !== 'undefined' && console && console.log) console.log('[CC]', label, obj);
    if (isDebugEnabled_()) {
      let s = '';
      try { s = JSON.stringify(obj); } catch(e){ s = String(obj); }
      try { __debugShow_(String(label || 'LOG'), (s || '').slice(0, 1500)); } catch(_){ }
    }
  }catch(_){ }
}
function safeLog(label, obj){ return safeLog_(label, obj); }

// Mock: LISTAS
// (Asegúrate de que los IDs coincidan con tus capturas)
const MOCK = {
  clientes: [
    { id:'CLI-2025-0007', title:'Marta R.', sub:'NIF: X1234567A · Barcelona', right:'Activo',
      email:'marta@email.com', phone:'+34 600 123 123', city:'Barcelona', status:'Activo' },
    { id:'CLI-2025-0008', title:'Comunidad Pineda', sub:'NIF: B66778899 · Pineda de Mar', right:'Lead',
      email:'admin@pineda.com', phone:'+34 611 222 333', city:'Pineda de Mar', status:'Lead' }
  ],
  leads: [
    { id:'L0009', title:'Comunidad Pineda (Lead)', sub:'Email: admin@pineda.com · Pineda de Mar', right:'Nuevo',
      email:'admin@pineda.com', phone:'+34 611 222 333', city:'Pineda de Mar', status:'Nuevo' }
  ],
  facturas: [
    { id:'F-2025-0123', title:'Factura F-2025-0123', sub:'CLI-2025-0007 · Pendiente', right:'120 €',
      clientId:'CLI-2025-0007', status:'Pendiente', amount:120 },
    { id:'F-2025-0124', title:'Factura F-2025-0124', sub:'CLI-2025-0008 · Pagada', right:'240 €',
      clientId:'CLI-2025-0008', status:'Pagada', amount:240 }
  ],
  proformas: [
    { id:'PRO-2025-0009', title:'Proforma PRO-2025-0009', sub:'CLI-2025-0007 · Enviada', right:'290,40 €',
      clientId:'CLI-2025-0007', status:'Enviada', amount:290.40 }
  ],
  gastos: [
    { id:'G-2025-0042', title:'Gasto G-2025-0042', sub:'Operación · Gasolina', right:'48,00 €',
      clientId:'CLI-2025-0007', status:'Ok', amount:48.00 }
  ]
};

// =========================
// Mock: DETALLE
   // (Si no existe aquí, mostramos fallback)
const MOCK_DETAIL = {
  clientes: {
    'CLI-2025-0007': {
      id:'CLI-2025-0007',
      title:'Marta R.',
      sub:'NIF: X1234567A · Barcelona',
      status:'Activo',
      email:'marta@email.com',
      phone:'+34 600 123 123',
      address:'Barcelona'
    },
    'CLI-2025-0008': {
      id:'CLI-2025-0008',
      title:'Comunidad Pineda',
      sub:'NIF: B66778899 · Pineda de Mar',
      status:'Lead',
      email:'admin@pineda.com',
      phone:'+34 611 222 333',
      address:'Pineda de Mar'
    }
  },
  leads: {
    'L0009': {
      id:'L0009',
      title:'Comunidad Pineda (Lead)',
      sub:'Email: admin@pineda.com · Pineda de Mar',
      status:'Nuevo',
      email:'admin@pineda.com',
      phone:'+34 611 222 333',
      address:'Pineda de Mar'
    }
  },
  facturas: {
    'F-2025-0123': {
      id:'F-2025-0123',
      title:'Factura F-2025-0123',
      sub:'CLI-2025-0007 · Pendiente',
      status:'Pendiente',
      amount:120,
      clientId:'CLI-2025-0007'
    },
    'F-2025-0124': {
      id:'F-2025-0124',
      title:'Factura F-2025-0124',
      sub:'CLI-2025-0008 · Pagada',
      status:'Pagada',
      amount:240,
      clientId:'CLI-2025-0008'
    }
  },
  proformas: {
    'PRO-2025-0009': {
      id:'PRO-2025-0009',
      title:'Proforma PRO-2025-0009',
      sub:'CLI-2025-0007 · Enviada',
      status:'Enviada',
      amount:290.40,
      clientId:'CLI-2025-0007'
    }
  },
  gastos: {
    'G-2025-0042': {
      id:'G-2025-0042',
      title:'Gasto G-2025-0042',
      sub:'Operación · Gasolina',
      status:'Ok',
      amount:48.00,
      clientId:'CLI-2025-0007'
    }
  }
};

// =========================
// UI: Toasts
function toast(title, msg, tone='ok'){
  // Asegura host .cc-toasts (si no existe, créalo)
  let host = qs('.cc-toasts');
  if (!host) {
    host = document.createElement('div');
    host.className = 'cc-toasts';
    host.style.position = 'fixed';
    host.style.top = '12px';
    host.style.right = '12px';
    host.style.zIndex = '99999';
    host.style.display = 'flex';
    host.style.flexDirection = 'column';
    host.style.gap = '10px';
    document.body.appendChild(host);
  }

  // Detectar debug=1 (preferencia: state.urlParams si ya existe)
  let debug = false;
  try {
    const d = state?.urlParams?.debug;
    const s = String(d ?? '').trim().toLowerCase();
    debug = (s === '1' || s === 'true');
  } catch (_) {}
  if (!debug) {
    try {
      const sp = new URLSearchParams(location.search || '');
      const s = String(sp.get('debug') ?? '').trim().toLowerCase();
      debug = (s === '1' || s === 'true');
    } catch (_) {}
  }

  // Panel fijo para debug (copiable)
  if (debug) {
    let panel = document.getElementById('ccDebugPanel');
    if (!panel) {
      panel = document.createElement('div');
      panel.id = 'ccDebugPanel';
      panel.style.position = 'fixed';
      panel.style.left = '12px';
      panel.style.top = '12px';
      panel.style.zIndex = '99998';
      panel.style.maxWidth = '620px';
      panel.style.width = 'calc(100vw - 24px)';
      panel.style.background = 'rgba(0,0,0,.55)';
      panel.style.border = '1px solid rgba(255,255,255,.12)';
      panel.style.borderRadius = '14px';
      panel.style.padding = '10px 12px';
      panel.style.backdropFilter = 'blur(8px)';
      panel.style.fontFamily = 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace';
      panel.style.fontSize = '12px';
      panel.style.color = '#EDEDED';

      panel.innerHTML = `
        <div style="display:flex; align-items:center; justify-content:space-between; gap:8px;">
          <div style="font-weight:700;">DEBUG (API)</div>
          <div style="display:flex; gap:8px;">
            <button id="ccDebugCopy" style="cursor:pointer; padding:6px 10px; border-radius:10px; border:1px solid rgba(255,255,255,.15); background:rgba(255,255,255,.06); color:#EDEDED;">Copiar</button>
            <button id="ccDebugClear" style="cursor:pointer; padding:6px 10px; border-radius:10px; border:1px solid rgba(255,255,255,.15); background:rgba(255,255,255,.06); color:#EDEDED;">Limpiar</button>
          </div>
        </div>
        <div id="ccDebugLog" style="margin-top:8px; max-height:160px; overflow:auto; white-space:pre-wrap;"></div>
      `;
      document.body.appendChild(panel);

      // handlers
      const copyBtn = panel.querySelector('#ccDebugCopy');
      const clearBtn = panel.querySelector('#ccDebugClear');
      copyBtn?.addEventListener('click', async () => {
        try {
          const txt = panel.querySelector('#ccDebugLog')?.innerText || '';
          await navigator.clipboard.writeText(txt);
          // mini feedback
          try { toast('DEBUG', 'Log copiado al portapapeles', 'ok'); } catch (_) {}
        } catch (_) {}
      });
      clearBtn?.addEventListener('click', () => {
        const log = panel.querySelector('#ccDebugLog');
        if (log) log.textContent = '';
      });
    }

    const log = document.getElementById('ccDebugLog');
    if (log) {
      const t = new Date().toLocaleTimeString('es-ES');
      const line = document.createElement('div');
      line.textContent = `${t} [${tone}] ${title}: ${msg}`;
      log.prepend(line);
    }
  }

  // Toast normal (visual)
  const el = document.createElement('div');
  el.className = `cc-toast cc-toast--${tone}`;
  el.innerHTML = `
    <div class="cc-toastTitle">${escapeHtml(title)}</div>
    <div class="cc-toastMsg">${escapeHtml(msg)}</div>
  `;
  host.appendChild(el);

  setTimeout(() => el.classList.add('is-in'), 10);
  const ttl = debug ? 10000 : 2500;
  setTimeout(() => {
    el.classList.remove('is-in');
    setTimeout(() => el.remove(), 200);
  }, ttl);
}

function escapeHtml(s){
  return String(s ?? '')
    .replaceAll('&','&amp;')
    .replaceAll('<','&lt;')
    .replaceAll('>','&gt;')
    .replaceAll('"','&quot;')
    .replaceAll("'","&#039;");
}

function loadMockPreference_(){
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.useMock);
    if (saved !== null) {
      state.useMock = saved === 'true';
      return;
    }
    const legacy = localStorage.getItem(STORAGE_KEYS.legacyUseMock);
    if (legacy !== null) {
      state.useMock = legacy === 'true';
      try { localStorage.setItem(STORAGE_KEYS.useMock, String(state.useMock)); } catch(_){ }
      try { localStorage.removeItem(STORAGE_KEYS.legacyUseMock); } catch(_){ }
      return;
    }
  } catch (_) {}
}

function applyMockFromUrl_(){
  try{
    const sp = new URLSearchParams(location.search);
    if (!sp.has('mock')) return;
    const v = String(sp.get('mock')).trim().toLowerCase();
    if (v === '0' || v === 'false') state.useMock = false;
    if (v === '1' || v === 'true')  state.useMock = true;
    saveMockPreference_();
  }catch(_){ }
}

function saveMockPreference_(){
  try {
    localStorage.setItem(STORAGE_KEYS.useMock, String(state.useMock));
  } catch (_) {}
}

function updateMockChip_(){
  if (!env.dev) {
    const chip = qs('[data-action="toggle_mock"]');
    if (chip) chip.remove();
    return;
  }
  const chip = qs('[data-action="toggle_mock"]');
  if(!chip) return;
  chip.classList.toggle('cc-chip--ok', !!state.useMock);
  chip.setAttribute('aria-pressed', state.useMock ? 'true' : 'false');
  chip.textContent = state.useMock ? 'Mock data' : 'Real data';
}

function callServer(fnName, ...args){
  return new Promise((resolve, reject) => {
    const runner = (typeof google !== 'undefined' && google && google.script && google.script.run) ? google.script.run : null;
    if (!runner) {
      reject(new Error('API no disponible (google.script.run)'));
      return;
    }

    const t0 = Date.now();
    const onOk = (res) => {
      try { safeLog('API OK ' + fnName, res); } catch(_){ }
      try { if (env && env.debug) toast('API OK', fnName + ' · ' + (Date.now()-t0) + 'ms', 'success'); } catch(_){ }
      resolve(res);
    };
    const onErr = (err) => {
      const msg = (err && err.message) ? err.message : String(err);
      try { safeLog('API ERROR ' + fnName, msg); } catch(_){ }
      try { toast('API ERROR', fnName + ' · ' + msg, 'error'); } catch(_){ }
      reject(err instanceof Error ? err : new Error(msg));
    };

    try { if (env && env.debug) toast('API', fnName + ' enviando...', 'info'); } catch(_){ }
    try {
      runner
        .withSuccessHandler(onOk)
        .withFailureHandler(onErr)[fnName]
        .apply(runner, args || []);
    } catch (e) {
      onErr(e);
    }
  });
}

function formatMoney(v){
  const n = Number(v);
  if (isNaN(n)) return '-';
  return `${n.toLocaleString('es-ES', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €`;
}

function formatDateText(v){
  if (!v) return '-';
  const d = new Date(v);
  if (isNaN(d.getTime())) return String(v);
  return d.toLocaleDateString('es-ES');
}

function pickValue_(obj, keys){
  if (!obj) return '';
  for (let i = 0; i < keys.length; i++) {
    const v = obj[keys[i]];
    if (v !== undefined && v !== null && String(v).trim() !== '') return v;
  }
  return '';
}

function toNumber_(v){
  const n = Number(v);
  return isNaN(n) ? null : n;
}

function joinParts_(parts){
  return parts.filter(Boolean).join(' | ');
}

 
// Normaliza respuestas del server:
// - [ ... ]                               => items
// - { items:[...]}                        => items
// - { data:{ items:[...]} }               => items
// - { ok:true, items:[...]}               => items
// - { ok:true, data:[...]}                => items
// - { ok:true, item:{...} }               => item (ver normalizeApiItem_)
function normalizeApiList_(res){
  if (!res) return [];
  if (Array.isArray(res)) return res;
  if (Array.isArray(res.items)) return res.items;
  if (Array.isArray(res.data)) return res.data;
  if (res.data && Array.isArray(res.data.items)) return res.data.items;
  if (res.result && Array.isArray(res.result.items)) return res.result.items;
  if (Array.isArray(res.rows)) return res.rows;
  if (res.data && Array.isArray(res.data.rows)) return res.data.rows;
  if (res.result && Array.isArray(res.result.rows)) return res.result.rows;
  return [];
}

function normalizeApiItem_(res){
  if (!res) return null;
  if (res.item && typeof res.item === 'object') return res.item;
  if (res.data && typeof res.data === 'object' && !Array.isArray(res.data)) return res.data;
  if (res.result && typeof res.result === 'object') return res.result;
  if (typeof res === 'object' && !Array.isArray(res)) return res;
  return null;
}

function setListState(mode, msg){
  const status = qs('#listState');
  const empty = qs('#listEmpty');
  const box = qs('#listContainer');
  if (!status || !empty || !box) return;

  if (mode === 'loading'){
    status.textContent = msg || 'Cargando...';
    status.style.display = 'block';
    status.style.color = 'inherit';
    empty.style.display = 'none';
    box.innerHTML = '';
    return;
  }

  if (mode === 'error'){
    status.textContent = msg || 'Error al cargar';
    status.style.display = 'block';
    status.style.color = '#b3261e';
    empty.style.display = 'none';
    box.innerHTML = '';
    return;
  }

  if (mode === 'empty'){
    status.style.display = 'none';
    status.style.color = 'inherit';
    empty.textContent = msg || 'Sin registros.';
    empty.style.display = 'block';
    box.innerHTML = '';
    return;
  }

  status.style.display = 'none';
  status.style.color = 'inherit';
  status.textContent = '';
  empty.style.display = 'none';
}

function setDetailState(mode, msg){
  const stateEl = qs('#detailState');
  if (!stateEl) return;
  if (mode === 'loading'){
    stateEl.textContent = msg || 'Cargando...';
    stateEl.style.display = 'block';
    stateEl.style.color = 'inherit';
    return;
  }
  if (mode === 'error'){
    stateEl.textContent = msg || 'No se pudo cargar el detalle';
    stateEl.style.display = 'block';
    stateEl.style.color = '#b3261e';
    return;
  }
  stateEl.style.display = 'none';
  stateEl.style.color = 'inherit';
  stateEl.textContent = '';
}

// ==========================
// UI: Navegación por pantallas
function showScreen(screenId){
  try{
    qsa('.cc-screen').forEach(s => s.classList.toggle('is-active', s.id === screenId));
    state.lastScreen = screenId;
  }catch(_){ }
}

function setNavActive(entity){
  try{
    qsa('.cc-navItem').forEach(b => b.classList.toggle('is-active', b.dataset.entity === entity));
  }catch(_){ }
}

function setActiveTab(entity){
  state.currentEntity = entity;
  try{
    qsa('.cc-tab').forEach(b => b.classList.toggle('is-active', b.dataset.entity === entity));
  }catch(_){ }
}


// ==========================
// DASHBOARD (mock simple)
// =========================
// DASHBOARD (real)
// ==========================
// DASHBOARD (real)
async function loadDashboard(){
  // Default UI mientras carga
  try{
    const ids = [
      'kpiVentasMes','kpiCobrado','kpiPendiente',
      'kpiFactPendientes','kpiFactPendientesSub',
      'kpiIvaNeto','kpiRepercutido','kpiSoportado',
      'kpiGastoDeducible','kpiCompras','kpiOperacion'
    ];
    ids.forEach(id => { const el = qs('#'+id); if(el) el.textContent = ''; });
  }catch(_){ }

  // Si estás en mock, no llamamos server
  if (state && state.useMock) return;

  try{
    const raw = await callServer('apiDashboard');
    const d = normalizeApiItem_(raw) || {};

    // Pintado mínimo (solo si existen elementos) sin romper si faltan campos
    const set = (id, val) => {
      try{
        const el = qs('#'+id);
        if(!el) return;
        el.textContent = (val===null || val===undefined) ? '' : String(val);
      }catch(_){ }
    };

    set('kpiVentasMes',         pickValue_(d, ['ventasMes','ventas_mes','ventas']));
    set('kpiCobrado',           pickValue_(d, ['cobradoMes','cobrado','cobrado_mes']));
    set('kpiPendiente',         pickValue_(d, ['pendienteMes','pendiente','pendiente_mes']));
    set('kpiFactPendientes',    pickValue_(d, ['facturasPendientes','factPendientes','pendientesCount','countPendientes']));
    set('kpiFactPendientesSub', pickValue_(d, ['facturasPendientesTotal','factPendientesTotal','pendientesTotal','totalPendiente']));
    set('kpiIvaNeto',           pickValue_(d, ['ivaNetoTrimestre','ivaNeto','iva_neto']));
    set('kpiRepercutido',       pickValue_(d, ['ivaRepercutido','repercutido','iva_repercutido']));
    set('kpiSoportado',         pickValue_(d, ['ivaSoportado','soportado','iva_soportado']));
    set('kpiGastoDeducible',    pickValue_(d, ['gastoDeducible','gasto_deducible']));
    set('kpiCompras',           pickValue_(d, ['compras','comprasMes','compras_mes']));
    set('kpiOperacion',         pickValue_(d, ['operacion','resultadoOperacion','resultado_operacion']));

  }catch(e){
    try{ toast('Dashboard', (e && e.message) ? e.message : String(e), 'error'); }catch(_){ }
  }
}

// ==========================
// PRESUPUESTOS (API)

function mapPresupuestoToView(p){
  if (!p) return null;
  const amount = (typeof p.total === 'number') ? p.total : (typeof p.base === 'number' ? p.base : null);
  return {
// id: p.id || p.Pres_ID,
// title: p.cliente || p.clienteId || p.id,
    sub: `${formatDateText(p.fecha || p.fechaRaw)} | ${p.estado || '-'}`,
// status: p.estado || '',
// amount,
// clientId: p.clienteId || '',
// email: p.email || '',
// phone: p.telefono || '',
// address: p.direccion || '',
// base: p.base ?? null,
// total: p.total ?? null,
    pdfUrl: p.pdfUrl || p.PDF_link || (p.raw && p.raw.PDF_link) || '',
// fecha: p.fecha || p.fechaRaw || '',
// notas: p.notas || '',
    lineas: Array.isArray(p.lineas) ? p.lineas : []
  };
}

function mapEntityListRow_(entity, row){
  if (!row) return null;

  if (entity === 'clientes' || entity === 'leads'){
    const id = row.id || pickValue_(row, ['Cliente_ID', 'Lead_ID', 'ID']);
    const name = row.nombre || pickValue_(row, ['Nombre', 'Cliente', 'Lead_Nombre']);
    const email = row.email || pickValue_(row, ['Email', 'Email_cliente', 'Lead_Email']);
    const phone = row.telefono || pickValue_(row, ['Telefono', 'Lead_Telefono', 'Phone']);
    const status = row.estado || pickValue_(row, ['Estado', 'Status']);
    return {
// id,
// title: name || id,
      sub: joinParts_([
        email ? `Email: ${email}` : '',
        phone ? `Tel: ${phone}` : ''
      ]),
// right: status || '',
// status: status || ''
    };
  }
  if (entity === 'facturas'){
    const id = String(pickValue_(row, ['Numero_factura','Factura_ID','ID']) || '');
    const cliente = String(pickValue_(row, ['Cliente','Cliente_nombre','Nombre']) || '');
    const nif = String(pickValue_(row, ['NIF','nif']) || '');
    const fecha = pickValue_(row, ['Fecha','fecha']) || '';
    const clienteId = String(pickValue_(row, ['Cliente_ID','ClienteId','Lead_ID']) || '');
    const status = String(pickValue_(row, ['Estado','Status','estado']) || '');

    const total = toNumber_(pickValue_(row, ['Total','total','Importe_total','Total_con_IVA']));
    const base  = toNumber_(pickValue_(row, ['Base','base','Subtotal','Base_imponible']));
    const amount = (total != null) ? total : base;

    return {
      sub: joinParts_([
        nif ? ('NIF: ' + nif) : '',
        fecha ? ('Fecha: ' + formatDateText(fecha)) : ''
      ]),
      right: amount != null ? formatMoney(amount) : (status || ''),
    };
  }

  if (entity === 'gastos'){
    const id = pickValue_(row, ['Gasto_ID', 'ID']);
    const proveedor = pickValue_(row, ['Proveedor', 'Empresa']);
    const concepto = pickValue_(row, ['Concepto', 'Descripcion', 'Detalle']);
    const categoria = pickValue_(row, ['Categoria', 'Tipo']);
    const total = toNumber_(pickValue_(row, ['Total', 'Importe_total', 'Total_con_IVA', 'Importe']));
    const base  = toNumber_(pickValue_(row, ['Base', 'Subtotal', 'Base_imponible']));
    const amount = (total != null) ? total : base;

    return {
      sub: joinParts_([proveedor, categoria, concepto]),
      right: amount != null ? formatMoney(amount) : (categoria || ''),
      clientId: pickValue_(row, ['Cliente_ID', 'ClienteId']) || ''
    };
  }

  return null;
}

function mapEntityDetail_(entity, row){
  if (!row) return null;

  if (entity === 'clientes' || entity === 'leads'){
    const id = row.id || pickValue_(row, ['Cliente_ID', 'Lead_ID', 'ID']);
    const name = row.nombre || pickValue_(row, ['Nombre', 'Cliente', 'Lead_Nombre']);
    const email = row.email || pickValue_(row, ['Email', 'Email_cliente', 'Lead_Email']);
    const phone = row.telefono || pickValue_(row, ['Telefono', 'Lead_Telefono', 'Phone']);
    const address = pickValue_(row, ['Direccion', 'Address', 'Direccion_cliente']);
    const status = row.estado || pickValue_(row, ['Estado', 'Status']);
    return {
// id,
// title: name || id,
      sub: joinParts_([
        email ? `Email: ${email}` : '',
        phone ? `Tel: ${phone}` : ''
      ]),
// status: status || '',
// email,
// phone,
// address
    };
  }
  if (entity === 'facturas'){
    const id = String(pickValue_(row, ['Numero_factura','Factura_ID','ID']) || '');
    const cliente = String(pickValue_(row, ['Cliente','cliente','Cliente_nombre','Nombre']) || '');
    const nif = String(pickValue_(row, ['NIF','nif']) || '');
    const fecha = pickValue_(row, ['Fecha','fecha']) || '';
    const clienteId = String(pickValue_(row, ['Cliente_ID','ClienteId','Lead_ID']) || '');
    const status = String(pickValue_(row, ['Estado','Status','estado']) || '');

    const base = toNumber_(pickValue_(row, ['Base','base','Subtotal','Base_imponible']));
}

const iva  = toNumber_(pickValue_(row, ['IVA','iva']));
}

const total = toNumber_(pickValue_(row, ['Total','total','Total_con_IVA','Importe_total']));
}

const pdf = String(pickValue_(row, ['PDF (link)','PDF_link','PDF','pdf']) || '');

    const amount = (total != null) ? total : base;

    return {
// id,
// title: cliente || id,
      sub: [
// nif ? 'NIF: ' + nif : '',
        fecha ? 'Fecha: ' + formatDateText(fecha) : ''
      ].filter(Boolean).join(' | '),
// status: status || '',
// clientId: clienteId || '',
// fecha,
      base: base != null ? base : null,
      iva: iva != null ? iva : null,
      total: total != null ? total : null,
      amount: amount != null ? amount : null,
// pdfLink: pdf
    };
  }

  if (entity === 'gastos'){
    const id = pickValue_(row, ['Gasto_ID', 'ID']);
    const proveedor = pickValue_(row, ['Proveedor', 'Empresa']);
    const concepto = pickValue_(row, ['Concepto', 'Descripcion', 'Detalle']);
    const categoria = pickValue_(row, ['Categoria', 'Tipo']);
    const fecha = pickValue_(row, ['Fecha']);
    const total = toNumber_(pickValue_(row, ['Total', 'Importe_total', 'Total_con_IVA', 'Importe']));
}

const base = toNumber_(pickValue_(row, ['Base', 'Subtotal', 'Base_imponible']));
}

const amount = total != null ? total : base;
    return {
// id,
// title: concepto || proveedor || id || 'Gasto',
// status: categoria || '',
// amount,
// base,
// total,
      clientId: pickValue_(row, ['Cliente_ID', 'ClienteId']) || '',
// fecha
    };
  }

  return null;
}

async function fetchEntityList(entity, search, filterClientId){
  const label = entity === 'clientes' ? 'clientes'
    : entity === 'leads' ? 'leads'
      : entity === 'facturas' ? 'facturas'
        : entity === 'gastos' ? 'gastos'
          : 'registros';
  setListState('loading', `Cargando ${label}...`);

  try {
    let raw = null;
    if (entity === 'clientes'){
      raw = await callServer('apiListClientes', { q: search || '' });
    } else if (entity === 'leads'){
      raw = await callServer('apiListLeads', { q: search || '' });
    } else {
      raw = await callServer('apiList', entity, { q: search || '', limit: 120 });
    }
    if (env && env.debug){
      try{
        const s = JSON.stringify(raw);
        const preview = s.slice(0, 300);
        toast('apiList raw', preview + (s.length > 300 ? '' : ''), 'info');
      }catch(_){}
    }

    const items = normalizeApiList_(raw);
    let rows = items.map(r => mapEntityListRow_(entity, r)).filter(r => r && r.id);
    if (filterClientId && entity !== 'clientes'){
      const needle = String(filterClientId).toLowerCase();
      rows = rows.filter(r => (r.clientId || '').toString().toLowerCase() === needle);
    }

    if (!rows.length){
      renderListItems(entity, []);
      setListState('empty', 'Sin registros.');
      return;
    }

    setListState();
    renderListItems(entity, rows);
  } catch (err) {
    console.error(err);
    setListState('error', err.message || 'No se pudo cargar');
  }
}

async function loadEntityDetail(entity, id){
  showScreen('screen-detalle');
  setDetailState('loading', 'Cargando detalle...');
  try {
    const raw = await callServer('apiGet', entity, id);
    const res = normalizeApiItem_(raw);
    safeLog_('apiGet '+entity, res);
    const view = mapEntityDetail_(entity, res);if (!view) throw new Error('No se encontro informacion');
    setDetailState();
    loadDetail(entity, view.id, view);
  } catch (err) {
    console.error(err);
    setDetailState('error', err.message || 'No se pudo cargar el detalle');
    toast('Error', err.message || 'No se pudo cargar el detalle', 'error');
  }
}

async function fetchPresupuestos(search, filterClientId){
  setListState('loading', 'Cargando presupuestos...');
  try {
    const res = await callServer('apiListPresupuestos', { q: search || '', includeHistorial: true });
    
    
    safeLog_('fetchPresupuestos', res);
safeLog_('apiListPresupuestos', res);
const items = normalizeApiList_(res);
    store.presupuestos = items;

    let list = store.presupuestos.slice();
    if (filterClientId){
      const needle = String(filterClientId).toLowerCase();
      list = list.filter(p => {
        const cid = (p.clienteId || p.Cliente_ID || p.Lead_ID || '').toString().toLowerCase();
        const cname = (p.cliente || '').toString().toLowerCase();
        return cid === needle || cname.includes(needle);
      });
    }

    if (!list.length){
      renderListItems('proformas', []);
      setListState('empty', filterClientId ? 'Sin presupuestos para este cliente' : 'Sin presupuestos aún');
      return;
    }

    const rows = list.map(p => {
      const view = mapPresupuestoToView(p);
      return {
// id: view.id,
// title: view.title,
// sub: view.sub,
        right: view.amount != null ? formatMoney(view.amount) : '',
// status: view.status,
// clientId: view.clientId
      };
    });

    setListState();
    renderListItems('proformas', rows);
  } catch (err) {
    console.error(err);
    setListState('error', err.message || 'No se pudo cargar presupuestos');
  }
}

async function loadPresupuestoDetail(id){
  showScreen('screen-detalle');
  setDetailState('loading', 'Cargando presupuesto...');
  try {
    const cached = store.presDetalle[id];
    const res = cached || await callServer('apiGetPresupuesto', id);
    if (!cached) store.presDetalle[id] = res;

    const view = mapPresupuestoToView(res);
    if (!view) throw new Error('No se encontró información del presupuesto');

    setDetailState();
    loadDetail('proformas', view.id, view);
  } catch (err) {
    console.error(err);
    setDetailState('error', err.message || 'Error al obtener presupuesto');
    toast('Error', err.message || 'No se pudo cargar el presupuesto', 'error');
  }
}

// ==========================
// LISTAS
function renderListItems(entity, rows){
  const box = qs('#listContainer');
  const empty = qs('#listEmpty');
  if (!box) return;

  if (!rows || !rows.length){
    box.innerHTML = '';
    if (empty) empty.style.display = 'block';
    return;
  }
  if (empty) empty.style.display = 'none';

  box.innerHTML = rows.map(r => `
    <button class="cc-item" type="button" data-entity="${escapeHtml(entity)}" data-id="${escapeHtml(r.id)}">
      <div class="cc-itemMain">
        <div class="cc-itemTitle">${escapeHtml(r.title || r.id)}</div>
        <div class="cc-itemSub">${escapeHtml(r.sub || '')}</div>
      </div>
      <div class="cc-itemRight">${escapeHtml(r.right || '')}</div>
    </button>
  `).join('');
}

function loadList(entity){
  const q = (qs('#q')?.value || '').toLowerCase().trim();

  if (!state.useMock){
    if (entity === 'proformas'){
      fetchPresupuestos(q, state.listFilterClientId);
      return;
    }
    fetchEntityList(entity, q, state.listFilterClientId);
    return;
  }

  setListState();
  let rows = (MOCK[entity] || []);

  // Filtro por cliente (historial)
  if (state.listFilterClientId && entity !== 'clientes'){
    rows = rows.filter(r => (r.clientId || '').toLowerCase() === state.listFilterClientId.toLowerCase());
}

  // Filtro por búsqueda
  if (q){
    rows = rows.filter(r => {
      const hay = `${r.id} ${r.title||''} ${r.sub||''} ${r.right||''}`.toLowerCase();
      return hay.includes(q);
    });
  }

  renderListItems(entity, rows);

  if (!rows.length){
    setListState('empty', 'Sin registros.');
  }
}

// ==========================
// DETALLE (render reusable)
function loadDetail(entity, id, detailData){
  state.detail.entity = entity;
  state.detail.id = id;

  const fallback = (MOCK_DETAIL?.[entity]?.[id]) || null;
  const data = detailData || fallback;
  state.detail.clientId = data?.clientId || data?.clienteId || null;

  const statusText = data?.status || data?.estado || '';
  const amountVal = (typeof data?.amount === 'number')
    ? data.amount
    : (typeof data?.total === 'number')
      ? data.total
      : (typeof data?.base === 'number' ? data.base : null);

  const subPieces = [];
  if (data?.fecha) subPieces.push(`Fecha: ${formatDateText(data.fecha)}`);
  if (statusText) subPieces.push(`Estado: ${statusText}`);
  if (data?.sub && !subPieces.length) subPieces.push(data.sub);

  qs('#detailId') && (qs('#detailId').textContent = id || '-');
  qs('#detailTitle') && (qs('#detailTitle').textContent = data?.title || data?.cliente || data?.id || id || 'Sin datos');
  qs('#detailSub') && (qs('#detailSub').textContent = subPieces.join(' | ') || data?.sub || 'Sin informacion');

  const pill = qs('#detailTypePill');
  if (pill){
    pill.textContent = entity === 'proformas' ? 'Presupuesto' : entity;
  }

  const statusPill = qs('#detailStatusPill');
  if (statusPill){
    statusPill.style.display = statusText ? 'inline-flex' : 'none';
    statusPill.textContent = statusText || '-';
  }

  const amountEl = qs('#detailAmount');
  if (amountEl){
    amountEl.style.display = amountVal != null ? 'block' : 'none';
    amountEl.textContent = amountVal != null ? formatMoney(amountVal) : '';
  }

  renderDetail(entity, id, data);
  renderDetailLines(data?.lineas);

  if (entity === 'clientes') setNavActive('clientes');
  if (entity === 'leads') setNavActive('leads');
  if (entity === 'facturas') setNavActive('facturas');
  if (entity === 'proformas') setNavActive('proformas');
  if (entity === 'gastos') setNavActive('gastos');
}

function renderDetail(entity, id, data){
  const actionsMain = qs('#detailActions');
  const meta = qs('#detailMeta');
  const quick = qs('#detailQuickActions');

  if (actionsMain) actionsMain.innerHTML = '';
  if (meta) meta.innerHTML = '';
  if (quick) quick.innerHTML = '';

  const status = data?.status || data?.estado || '';
  const clientId = data?.clientId || data?.clienteId || null;
  const amountVal = (typeof data?.amount === 'number') ? data.amount : (typeof data?.total === 'number' ? data.total : null);
  const baseVal = (typeof data?.base === 'number') ? data.base : null;
  const fechaVal = data?.fecha || '';

  // LEAD
  if (entity === 'leads'){
    const email = data?.email || '-';
    const phone = data?.phone || '-';
    const address = data?.address || '-';

    if (actionsMain){
      actionsMain.innerHTML = `
        <button class="cc-btn cc-btn--primary cc-btn--wide" type="button" data-action="crear_presupuesto_lead" data-entity="leads" data-id="${escapeHtml(id)}">
          <span aria-hidden="true">+</span> Crear presupuesto
        </button>
        <button class="cc-btn cc-btn--primary cc-btn--wide" type="button" data-action="lead_ganar" data-entity="leads" data-id="${escapeHtml(id)}">
          <span aria-hidden="true">✅</span> Marcar GANADO → Pasar a Cliente
        </button>
      `;
    }

    if (meta){
      meta.innerHTML = `
        <div class="cc-metaCard">
          <div class="cc-metaLabel">EMAIL</div>
          <div class="cc-metaValue">${escapeHtml(email)}</div>
        </div>
        <div class="cc-metaCard">
          <div class="cc-metaLabel">TELEFONO</div>
          <div class="cc-metaValue">${escapeHtml(phone)}</div>
        </div>
        <div class="cc-metaCard">
          <div class="cc-metaLabel">DIRECCION</div>
          <div class="cc-metaValue">${escapeHtml(address)}</div>
        </div>
      `;
    }

    if (quick){
      quick.innerHTML = `
        <button class="cc-quickItem" type="button" data-action="volver" data-entity="${escapeHtml(entity)}" data-id="${escapeHtml(id)}">
          <div class="cc-quickLeft">
            <div class="cc-quickTitle">Volver</div>
            <div class="cc-quickSub">Regresar a listas</div>
          </div>
          <div class="cc-quickRight" aria-hidden="true">&larr;</div>
        </button>
      `;
    }

    return;
  }

  // CLIENTE
  if (entity === 'clientes'){
    const email = data?.email || '—';
    const phone = data?.phone || '—';
    const address = data?.address || '—';

    // Acciones principales grandes (como la versión que quieres)
    if (actionsMain){
      actionsMain.innerHTML = `
        <button class="cc-btn cc-btn--primary cc-btn--wide" type="button" data-action="crear_proforma" data-entity="clientes" data-id="${escapeHtml(id)}">
          <span aria-hidden="true">➕</span> Crear proforma
        </button>
        <button class="cc-btn cc-btn--primary cc-btn--wide" type="button" data-action="crear_factura" data-entity="clientes" data-id="${escapeHtml(id)}">
          <span aria-hidden="true">🧾</span> Crear factura
        </button>
        <button class="cc-btn cc-btn--wide" type="button" data-action="ver_historial" data-entity="clientes" data-id="${escapeHtml(id)}">
          <span aria-hidden="true">📚</span> Ver historial
        </button>
      `;
    }

    // Meta cards (Email / Teléfono / Dirección)
    if (meta){
      meta.innerHTML = `
        <div class="cc-metaCard">
          <div class="cc-metaLabel">EMAIL</div>
          <div class="cc-metaValue">${escapeHtml(email)}</div>
        </div>
        <div class="cc-metaCard">
          <div class="cc-metaLabel">TELÉFONO</div>
          <div class="cc-metaValue">${escapeHtml(phone)}</div>
        </div>
        <div class="cc-metaCard">
          <div class="cc-metaLabel">DIRECCIÓN</div>
          <div class="cc-metaValue">${escapeHtml(address)}</div>
        </div>
      `;
    }

    // Quick actions (lista)
    if (quick){
      quick.innerHTML = `
        <button class="cc-quickItem" type="button" data-action="wa_chat" data-entity="clientes" data-id="${escapeHtml(id)}">
          <div class="cc-quickLeft">
            <div class="cc-quickTitle">WhatsApp</div>
            <div class="cc-quickSub">Abrir chat rápido</div>
          </div>
          <div class="cc-quickRight" aria-hidden="true">↗</div>
        </button>

        <button class="cc-quickItem" type="button" data-action="call_phone" data-entity="clientes" data-id="${escapeHtml(id)}">
          <div class="cc-quickLeft">
            <div class="cc-quickTitle">Llamar</div>
            <div class="cc-quickSub">Marcar teléfono</div>
          </div>
          <div class="cc-quickRight" aria-hidden="true">↗</div>
        </button>

        <button class="cc-quickItem" type="button" data-action="send_email" data-entity="clientes" data-id="${escapeHtml(id)}">
          <div class="cc-quickLeft">
            <div class="cc-quickTitle">Email</div>
            <div class="cc-quickSub">Enviar correo</div>
          </div>
          <div class="cc-quickRight" aria-hidden="true">↗</div>
        </button>

        <button class="cc-quickItem" type="button" data-action="copy_id" data-entity="clientes" data-id="${escapeHtml(id)}">
          <div class="cc-quickLeft">
            <div class="cc-quickTitle">Copiar datos</div>
            <div class="cc-quickSub">ID + contacto</div>
          </div>
          <div class="cc-quickRight" aria-hidden="true">⧉</div>
        </button>

        <button class="cc-quickItem" type="button" data-action="ver_proformas" data-entity="clientes" data-id="${escapeHtml(id)}">
          <div class="cc-quickLeft">
            <div class="cc-quickTitle">Ver proformas</div>
            <div class="cc-quickSub">Filtrar por cliente</div>
          </div>
          <div class="cc-quickRight" aria-hidden="true">→</div>
        </button>

        <button class="cc-quickItem" type="button" data-action="ver_gastos" data-entity="clientes" data-id="${escapeHtml(id)}">
          <div class="cc-quickLeft">
            <div class="cc-quickTitle">Ver gastos</div>
            <div class="cc-quickSub">Filtrar por cliente</div>
          </div>
          <div class="cc-quickRight" aria-hidden="true">→</div>
        </button>
      `;
    }

    return;
  }

  // FACTURA / PROFORMA / GASTO
  state.detail.clientId = clientId;

  if (actionsMain){
    // Botones principales para documentos
    if (entity === 'facturas'){
      actionsMain.innerHTML =
        '<button class="cc-btn cc-btn--primary cc-btn--wide" type="button" data-action="abrir_pdf" data-entity="facturas" data-id="' + escapeHtml(id) + '">' +
          '<span aria-hidden="true"></span> Abrir PDF' +
        '</button>' +
        '<button class="cc-btn cc-btn--wide" type="button" data-action="marcar_pagada" data-entity="facturas" data-id="' + escapeHtml(id) + '">' +
          '<span aria-hidden="true"></span> Marcar pagada' +
        '</button>' +
        '<button class="cc-btn cc-btn--wide" type="button" data-action="volver_cliente" data-entity="facturas" data-id="' + escapeHtml(id) + '" data-clientid="' + escapeHtml(clientId || '') + '">' +
          '<span aria-hidden="true"></span> Volver a cliente' +
        '</button>';
    } else if (entity === 'proformas'){
      actionsMain.innerHTML = `
        <button class="cc-btn cc-btn--primary cc-btn--wide" type="button" data-action="generar_pdf" data-entity="proformas" data-id="${escapeHtml(id)}">
          <span aria-hidden="true">?</span> Generar PDF
        </button>
        <button class="cc-btn cc-btn--primary cc-btn--wide" type="button" data-action="abrir_pdf" data-entity="proformas" data-id="${escapeHtml(id)}">
          <span aria-hidden="true">??</span> Abrir PDF
        </button>
        <button class="cc-btn cc-btn--wide" type="button" data-action="aceptar_proforma" data-entity="proformas" data-id="${escapeHtml(id)}">
          <span aria-hidden="true">??</span> Aceptar
        </button>
        <button class="cc-btn cc-btn--wide" type="button" data-action="crear_factura" data-entity="proformas" data-id="${escapeHtml(id)}">
          <span aria-hidden="true">??</span> Crear factura
        </button>
        <button class="cc-btn cc-btn--wide" type="button" data-action="perder_proforma" data-entity="proformas" data-id="${escapeHtml(id)}">
          <span aria-hidden="true">?</span> Marcar perdida
        </button>
      `;
    } else if (entity === 'gastos'){
      actionsMain.innerHTML = `
        <button class="cc-btn cc-btn--primary cc-btn--wide" type="button" data-action="adjuntar_pdf" data-entity="gastos" data-id="${escapeHtml(id)}">
          <span aria-hidden="true">📎</span> Adjuntar PDF
        </button>
        <button class="cc-btn cc-btn--wide" type="button" data-action="editar_gasto" data-entity="gastos" data-id="${escapeHtml(id)}">
          <span aria-hidden="true">✏️</span> Editar gasto
        </button>
        <button class="cc-btn cc-btn--wide" type="button" data-action="eliminar_gasto" data-entity="gastos" data-id="${escapeHtml(id)}">
          <span aria-hidden="true">🗑</span> Eliminar
        </button>
      `;
    }
  }

  // Meta info del documento
  if (meta){
    meta.innerHTML = `
      <div class="cc-metaCard">
        <div class="cc-metaLabel">CLIENTE</div>
        <div class="cc-metaValue">${escapeHtml(clientId || '—')}</div>
      </div>
      <div class="cc-metaCard">
        <div class="cc-metaLabel">ESTADO</div>
        <div class="cc-metaValue">${escapeHtml(data?.status || '—')}</div>
      </div>
      <div class="cc-metaCard">
        <div class="cc-metaLabel">IMPORTE</div>
        <div class="cc-metaValue">${escapeHtml((typeof data?.amount === 'number') ? `${data.amount.toFixed(2)} €` : '—')}</div>
      </div>
    `;
  }

  // Quick actions mínimas para docs
  if (quick){
    quick.innerHTML = `
      <button class="cc-quickItem" type="button" data-action="volver" data-entity="${escapeHtml(entity)}" data-id="${escapeHtml(id)}">
        <div class="cc-quickLeft">
          <div class="cc-quickTitle">Volver</div>
          <div class="cc-quickSub">Regresar a listas</div>
        </div>
        <div class="cc-quickRight" aria-hidden="true">←</div>
      </button>
    `;
  }
}

function renderDetailLines(lines){
  const box = qs('#detailLines');
  const empty = qs('#detailLinesEmpty');
  if (!box || !empty) return;

  if (!Array.isArray(lines) || !lines.length){
    box.innerHTML = '';
    empty.style.display = 'block';
    return;
  }

  empty.style.display = 'none';
  box.innerHTML = lines.map(l => {
    const parts = [];
    if (l?.cantidad != null && l?.precio != null){
      parts.push(`Cant: ${l.cantidad} x ${formatMoney(l.precio)}`);
    } else if (l?.cantidad != null){
      parts.push(`Cant: ${l.cantidad}`);
    }
    if (l?.dto != null) parts.push(`Dto: ${l.dto}%`);
    if (l?.iva != null) parts.push(`IVA: ${l.iva}%`);

    const meta = parts.length ? parts.join(' · ') : '';
    const total = (typeof l?.subtotal === 'number')
      ? l.subtotal
      : (typeof l?.base === 'number' ? l.base : null);

    return `
      <div class="cc-lineItem">
        <div class="cc-lineTitle">${escapeHtml(l?.concepto || l?.descripcion || l?.Descripcion || '')}</div>
        <div class="cc-lineSub">${escapeHtml(total != null ? formatMoney(total) : '')}</div>
        <div class="cc-lineMeta">${escapeHtml(meta)}</div>
      </div>
    `;
  }).join('');
}

// ==========================
// Router de acciones (ÚNICO)
// Maneja SOLO elementos con [data-action]
function runAction(action, entity, id, dataset){
  const a = (action || '').toLowerCase().trim();

  // Toggle mock
  if (a === 'toggle_mock'){
    state.useMock = !state.useMock;
    saveMockPreference_();
    updateMockChip_();
    toast('Mock', state.useMock ? 'Activado' : 'Desactivado', 'info');
    if (state.lastScreen === 'screen-listas' && state.currentEntity){
      loadList(state.currentEntity);
    }
    return;
  }

  // Dashboard shortcuts
  if (a === 'go_form_cliente'){ openForm('Cliente'); return; }
  if (a === 'go_form_factura'){ openForm('Factura'); return; }
  if (a === 'go_form_proforma'){ openForm('Proforma'); return; }
  if (a === 'go_form_gasto'){ openForm('Gasto'); return; }

  // Cierre / ver todo / filtros (mock)
  if (a === 'cierre_trimestre'){ toast('Cierre', 'Mock: iniciar cierre de trimestre', 'info'); return; }
  if (a === 'ver_todo'){ toast('Movimientos', 'Mock: ver todo', 'info'); return; }
  if (a === 'abrir_filtro'){ toast('Filtro', 'Mock: panel de filtros', 'info'); return; }

  // Acciones de CLIENTE (detalle)
  if (a === 'crear_proforma'){
    toast('Listo', `Crear proforma desde ${id} (mock)`, 'ok');
    goToList('proformas', id);
    return;
  }
  if (a === 'crear_factura'){
    toast('Listo', `Crear factura desde ${id} (mock)`, 'ok');
    goToList('facturas', id);
    return;
  }
  if (a === 'crear_presupuesto_lead'){
    if (state.useMock){
      toast('Listo', `Crear presupuesto para ${id} (mock)`, 'ok');
      goToList('proformas', null);
      return;
    }
google.script.run
      .withSuccessHandler((res) => {
        const presId = res && res.presId ? res.presId : '(sin id)';
        toast('Listo', `Presupuesto creado: ${presId}`, 'ok');
        goToList('proformas', null);
      })
      .withFailureHandler((err) => {
        toast('Error', err && err.message ? err.message : String(err), 'info');
      })
      .apiCrearPresupuestoLead(id);
    return;
  }  
  // Lead: marcar GANADO → convertir a Cliente (REAL)
  if (a === 'lead_ganar'){
    if (state.useMock){
      toast('LEADS', 'Mock activo: desactiva MOCK para convertir.', 'info');
      return;
    }
    if (!id){
      toast('LEADS', 'Lead_ID vacio', 'info');
      return;
    }

    (async () => {
      try{
        toast('LEADS', 'Marcando GANADO y convirtiendo…', 'info');
        const res = await callServer('apiLeadMarcarGanado', id);
        safeLog_('apiLeadMarcarGanado', res);

        if (res && res.ok && res.clienteId){
          toast('LEADS', `✅ Convertido a cliente: ${res.clienteId}`, 'ok');
          loadEntityDetail('clientes', res.clienteId);
        } else {
          toast('LEADS', 'No se pudo convertir (sin Cliente_ID). Revisa el lead.', 'warn');
        }
      } catch(err){
        toast('LEADS', (err && err.message) ? err.message : String(err), 'error');
      }
    })();

    return;
  }

  if (a === 'ver_historial'){
    toast('Historial', `Mostrando facturas de ${id} (mock)`, 'info');
    goToList('facturas', id);
    return;
  }

  if (a === 'ver_proformas'){
    goToList('proformas', id);
    return;
  }
  if (a === 'ver_gastos'){
    goToList('gastos', id);
    return;
  }

  // Quick actions cliente
  if (a === 'wa_chat'){
    toast('WhatsApp', `Mock: abrir chat de ${id}`, 'info');
    return;
  }
  if (a === 'call_phone'){
    toast('Llamar', `Mock: llamar a ${id}`, 'info');
    return;
  }
  if (a === 'send_email'){
    toast('Email', `Mock: enviar email a ${id}`, 'info');
    return;
  }
  if (a === 'copy_id'){
    // Intento copiar
    const d = MOCK_DETAIL?.clientes?.[id];
    const txt = `ID: ${id}\nEmail: ${d?.email || '—'}\nTel: ${d?.phone || '—'}`;
    navigator.clipboard?.writeText(txt).then(
      () => toast('Copiado', 'Datos copiados al portapapeles', 'ok'),
      // () => toast('Copiar', 'No se pudo copiar (permiso del navegador)', 'info')
    );
}

return;
  }

  // Acciones de FACTURA / PROFORMA / GASTO (detalle)
  if (a === 'generar_pdf'){
    if (state.useMock){
      toast('PDF', `Mock: generar PDF de ${id}`, 'ok');
      return;
    }
    if (entity !== 'proformas'){
      toast('PDF', 'Generar PDF solo disponible en proformas desde la app', 'info');
      return;
    }
    toast('Generando', `Generando PDF ${id}...`, 'info');
    callServer('apiGeneratePresupuestoPdf', id)
      .then((res) => {
        const url = res && (res.pdfUrl || res.url);
        if (store.presDetalle[id]) store.presDetalle[id].pdfUrl = url || store.presDetalle[id].pdfUrl;
        if (url){
          toast('PDF', 'PDF listo', 'ok');
          try { window.open(url, '_blank'); } catch (_) {}
        } else {
          toast('PDF', 'No se recibio URL del PDF', 'info');
        }
      })
      .catch((err) => toast('Error', err?.message || 'No se pudo generar el PDF', 'error'));
}

return;
  }
  if (a === 'abrir_pdf'){
    // FACTURAS (real): abrir pdfLink si existe
    if (entity === 'facturas' && !state.useMock){
      if (!id){ toast('PDF', 'Factura_ID vacío', 'info'); return; }

      toast('PDF', 'Buscando enlace PDF...', 'info');
      callServer('apiGet', 'facturas', id)
        .then((res) => {
          const url =
            (res && (res.pdfLink || res.pdfUrl || res.PDF_link || res.url || res.link)) || '';
          if (url){
            toast('PDF', 'Abriendo PDF...', 'ok');
            try { window.open(url, '_blank'); } catch (_) { toast('PDF', url, 'info'); }
          } else {
            toast('PDF', 'Esta factura no tiene PDF aún', 'info');
          }
        })
        .catch((err) => toast('Error', (err && err.message) ? err.message : 'No se pudo abrir el PDF', 'error'));
}

return;
    }
if (entity === 'proformas' && !state.useMock){
      const detail = store.presDetalle[id];
      const saved = detail?.pdfUrl || detail?.PDF_link || '';
      if (saved){
        try { window.open(saved, '_blank'); } catch (_) { toast('PDF', saved, 'info'); }
        return;
      }
      toast('PDF', 'Generando PDF porque no hay enlace guardado...', 'info');
      callServer('apiGeneratePresupuestoPdf', id)
        .then((res) => {
          const link = res && (res.pdfUrl || res.url);
          if (store.presDetalle[id]) store.presDetalle[id].pdfUrl = link || store.presDetalle[id].pdfUrl;
          if (link){
            try { window.open(link, '_blank'); } catch (_) {}
          } else {
            toast('PDF', 'No se pudo obtener el PDF', 'error');
          }
        })
        .catch((err) => toast('Error', err?.message || 'No se pudo abrir el PDF', 'error'));
}

return;
    }
    toast('PDF', `Mock: abrir PDF de ${id}`, 'ok');
    return;
  }
  if (a === 'marcar_pagada'){ toast('Listo', `Factura ${id} marcada como pagada (mock)`, 'ok'); return; }
  if (a === 'aceptar_proforma'){ toast('Listo', `Proforma ${id} aceptada (mock)`, 'ok'); return; }
  if (a === 'convertir_factura'){ toast('Listo', `Convertir ${id} a factura (mock)`, 'ok'); return; }
  if (a === 'crear_factura'){
    if (state.useMock){
      toast('Listo', `Crear factura desde ${id} (mock)`, 'ok');
      return;
    }
    if (!id){
      toast('Error', 'Pres_ID vacio', 'info');
      return;
    }
    toast('Factura', `Creando factura desde ${id}...`, 'info');
    callServer('apiCrearFacturaDesdePresupuesto', id, { regenerarPdf: false })
      .then((res) => {
        const facturaId = res?.facturaId || '';
        const pdfUrl = res?.pdfUrl || '';
        const msg = res?.alreadyExisted ? `Factura existente: ${facturaId}` : `Factura creada: ${facturaId}`;
        toast('Factura', msg, 'ok');
        if (pdfUrl){
          try { window.open(pdfUrl, '_blank'); } catch (_) {}
        }
      })
      .catch((err) => toast('Error', err?.message || 'No se pudo crear la factura', 'error'));
}

return;
  }
  if (a === 'perder_proforma'){ toast('Listo', `Proforma ${id} marcada como perdida (mock)`, 'ok'); return; }
  if (a === 'adjuntar_pdf'){ toast('Listo', `Adjuntar PDF a ${id} (mock)`, 'ok'); return; }
  if (a === 'editar_gasto'){ toast('Editar', `Editar gasto ${id} (mock)`, 'info'); return; }
  if (a === 'eliminar_gasto'){ toast('Eliminado', `Gasto ${id} eliminado (mock)`, 'ok'); return; }

  // Volver a cliente (desde factura)
  if (a === 'volver_cliente'){
    const cid = (dataset && dataset.clientid) ? dataset.clientid : state.detail.clientId;
    if (!cid){ toast('Cliente', 'No hay clientId', 'info'); return; }
    __setHashRoute__('clientes', cid);
    return;
  }

  // Volver / cancelar / guardar form
  if (a === 'volver'){
    // URL-first
    if (state.lastScreen === 'screen-detalle' || state.lastScreen === 'screen-form'){
      __setHashRoute__(state.currentEntity, null);
    } else {
      __setHashRoute__('home', null);
    }
    return;
  }

  if (a === 'guardar_form'){
    toast('Guardado', 'Mock: registro guardado', 'ok');
    showScreen('screen-home');
    setNavActive('home');
    return;
  }

  // fuente / pendientes etc
  if (a === 'ver_fuente'){
    if (state.useMock){
      toast('Fuente', 'Mock: abrir spreadsheet', 'info');
      return;
    }

    callServer('apiDbInfo')
      .then((res) => {
        const t = (res && res.targets) ? res.targets : {};
        const ssid = (res && res.spreadsheetId) ? res.spreadsheetId : '-';

        const f = t.FACTURA || {};
        const p = t.PRESUPUESTOS || {};
        const h = t.PRES_HIST || {};
        const g = t.GASTOS || {};

        const filas = (x) => {
          const lr = Number(x && x.lastRow ? x.lastRow : 0);
          return Math.max(0, lr - 1); // descuenta headers
        };

        const msg =
          'SS: ' + ssid + '\n' +
          'FACTURA: ' + (f.exists ? 'OK' : 'NO') + ' (' + filas(f) + ' filas)\n' +
          'PRESUPUESTOS: ' + (p.exists ? 'OK' : 'NO') + ' (' + filas(p) + ' filas)\n' +
          'HIST: ' + (h.exists ? 'OK' : 'NO') + ' (' + filas(h) + ' filas)\n' +
          'GASTOS: ' + (g.exists ? 'OK' : 'NO') + ' (' + filas(g) + ' filas)';

        toast('Fuente', msg, 'info');
      })
      .catch((err) => {
        toast('Fuente', (err && err.message) ? err.message : String(err), 'error');
      });

    return;
  }

  if (a === 'ir_facturas_pendientes'){ goToList('facturas', null); return; }

  // default
  toast('Info', `Acción no implementada: ${action}`, 'info');
}

// =========================
// Router por URL (hash)
// #/facturas
// #/proformas/PRO-2025-0019
function __setHashRoute__(entity, id){
  try{
    const e = String(entity || '').trim();
    const i = (id === null || id === undefined) ? '' : String(id).trim();
    if (!e) return;

    const newHash =
      '#/' + encodeURIComponent(e) +
      (i ? '/' + encodeURIComponent(i) : '');

    if (location.hash !== newHash) location.hash = newHash;
  }catch(_){}
}

function __parseHashRoute__(){
  try{
    const h = String(location.hash || '').replace(/^#\/?/, '');
    if (!h) return { entity:'', id:'' };
    const parts = h.split('/').filter(Boolean);
    const entity = parts[0] ? decodeURIComponent(parts[0]) : '';
    const id = parts[1] ? decodeURIComponent(parts[1]) : '';
    return { entity, id };
  }catch(_){
    return { entity:'', id:'' };
  }
}

// Flag para evitar loops (hashchange -> goToList -> set hash -> hashchange...)
let __routeLock__ = false;

function __applyRouteFromHash__(){
  const r = __parseHashRoute__();
  const entity = (r.entity || '').trim();
  const id = (r.id || '').trim();

  if (!entity) return; // sin hash: no tocamos nada

  __routeLock__ = true;
  try{
    if (id){
      // Detalle
      if (!state.useMock){
        showScreen('screen-detalle');
        setDetailState();

        if (entity === 'proformas'){
          loadPresupuestoDetail(id);
          return;
        }
        loadEntityDetail(entity, id);
        return;
      }

      showScreen('screen-detalle');
      setDetailState();
      loadDetail(entity, id);
      return;
    }

    // Lista
    goToList(entity, null);
  }finally{
    __routeLock__ = false;
  }
}

// ==========================
// Navegación a listas
function goToList(entity, filterClientId){
  state.currentEntity = entity;
  state.listFilterClientId = filterClientId || null;

  // URL router (solo si NO venimos de hashchange)
  if (!__routeLock__) __setHashRoute__(entity, null);

  // UI
  showScreen('screen-listas');
  setNavActive(entity);
  setActiveTab(entity);

  // limpia búsqueda si filtramos por cliente (opcional)
  if (qs('#q')) qs('#q').value = '';

  loadList(entity);
}

// ==========================
// Form mock
function openForm(kind){
  showScreen('screen-form');
  setNavActive('home');
  if (qs('#formTitle')) qs('#formTitle').textContent = `Crear ${kind} (ejemplo)`;
  if (qs('#formSub')) qs('#formSub').textContent = `${kind.toUpperCase()}-2025-xxxx`;
  toast('Formulario', `Mock: ${kind}`, 'info');
}

// ==========================
// INIT: listeners
function initNav(){
  qsa('.cc-navItem').forEach(btn => {
    btn.addEventListener('click', () => {
      const screenId = btn.dataset.screen;
      const entity = btn.dataset.entity;

      if (!screenId) return;

      // Home
      if (screenId === 'screen-home'){
        state.listFilterClientId = null;
        showScreen('screen-home');
        setNavActive('home');
        loadDashboard();
        return;
      }

      // Listas
      if (screenId === 'screen-listas'){
        goToList(entity || 'clientes', null);
        return;
      }

      showScreen(screenId);
      setNavActive(entity || 'home');
    });
  });
}

function initListTabs(){
  qsa('.cc-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      const entity = btn.dataset.entity;
      if (!entity) return;

      // Centralizamos en goToList: mantiene state.currentEntity + UI + filtro + búsqueda
      goToList(entity, null);
    });
  });
}

// ==========================
// Listener global:
// - [data-action] => runAction
// - .cc-item (lista) => abrir detalle
document.addEventListener('click', (e) => {
  // 1) Actions
  const actEl = e.target.closest('[data-action]');
  if (actEl){
    e.preventDefault();
    const action = actEl.dataset.action;
    const entity = (actEl.dataset.entity || '').trim();
    const id = (actEl.dataset.id || '').trim();
    runAction(action, entity, id, actEl.dataset);
    return;
  }

  // 2) Click en item de lista
  const item = e.target.closest('.cc-item');
  if (item){
    const entity = item.dataset.entity;
    const id = item.dataset.id;
    if (!entity || !id) return;
    e.preventDefault();

    if (!state.useMock){
  // Detalle por URL
  __setHashRoute__(entity, id);
  return;
}

    showScreen('screen-detalle');
    setDetailState();
    loadDetail(entity, id);
    return;
  }
});

// =========================
// Search input (filtro)
document.addEventListener('input', (e) => {
  if (e.target && e.target.id === 'q'){
    loadList(state.currentEntity);
  }
});

// =========================
// INIT APP
function __forceRealFromUrl_(){
  try{
    const sp = new URLSearchParams(window.location.search || '');
    if (sp.get('real') === '1'){
      state.useMock = false;
      try{ localStorage.removeItem('cc_useMock'); }catch(_){}
      try{ saveMockPreference_(); }catch(_){}
      try{ updateMockChip_(); }catch(_){}
      try{ toast('Modo', 'REAL activado (?real=1)', 'ok'); }catch(_){}
      return true;
    }
  }catch(_){}
  return false;
}

function __installGlobalErrorCatcher_(){
  try{ __ensureDebugPanel_(); }catch(_){}

  try{
    window.addEventListener('error', (e) => {
      const msg = (e && e.message) ? e.message : String(e);
      try{ toast('JS Error', msg, 'error'); } catch(_){ try{ alert('JS Error: ' + msg); }catch(__){} }
      try{ __debugShow_('JS ERROR', msg); }catch(_){}
    });

    window.addEventListener('unhandledrejection', (e) => {
      const r = e && e.reason ? e.reason : e;
      const msg = (r && r.message) ? r.message : String(r);
      try{ toast('Promise', msg, 'error'); } catch(_){ try{ alert('Promise: ' + msg); }catch(__){} }
      try{ __debugShow_('PROMISE', msg); }catch(_){}
    });
  }catch(_){}
}

document.addEventListener('DOMContentLoaded', () => {
  try{ __debugShow_('INIT', 'DOMContentLoaded fired · search=' + (location && location.search ? location.search : '')); catch(_){}
    }

  __debugShow_('ENV', JSON.stringify({
    search: (location && location.search) ? location.search : '',
    env: (typeof env !== 'undefined') ? env : null,
    useMock: (typeof state !== 'undefined') ? state.useMock : null
  }, null, 2));
}

  __debugShow_('ENV', JSON.stringify({
    search: (location && location.search) ? location.search : '',
    env: (typeof env !== 'undefined') ? env : null,
    useMock: (typeof state !== 'undefined') ? state.useMock : null
  }, null, 2));
}

  __installGlobalErrorCatcher_();

  // mock/real (storage -> url -> force real)
  try { loadMockPreference_(); } catch(e){ try{ toast('Init', 'loadMockPreference: ' + ((e&&e.message)?e.message:String(e)), 'error'); }catch(_){ } }
  try { applyMockFromUrl_(); } catch(e){ try{ toast('Init', 'applyMockFromUrl: ' + ((e&&e.message)?e.message:String(e)), 'error'); }catch(_){ } }
  try { __forceRealFromUrl_(); } catch(e){ try{ toast('Init', '__forceRealFromUrl: ' + ((e&&e.message)?e.message:String(e)), 'error'); }catch(_){ } }

  // UI primero (blindado)
  try { initNav(); } catch(e){ try{ toast('Init', 'initNav: ' + ((e&&e.message)?e.message:String(e)), 'error'); }catch(_){ } }
  try { initListTabs(); } catch(e){ try{ toast('Init', 'initListTabs: ' + ((e&&e.message)?e.message:String(e)), 'error'); }catch(_){ } }
  try { updateMockChip_(); } catch(e){}

  // estado inicial
  try { showScreen('screen-home'); } catch(e){}
document.addEventListener('DOMContentLoaded', () => {
  // señal debug (no rompe si debug panel no existe)
  try{ __debugShow_('INIT', 'DOMContentLoaded fired · search=' + (location && location.search ? location.search : '')); }catch(_){ }
  try{ toast('INIT', 'DOMContentLoaded fired', 'info'); }catch(_){ }

  __installGlobalErrorCatcher_();

  // mock/real (storage -> url -> force real)
  try { loadMockPreference_(); } catch(e){ try{ toast('Init', 'loadMockPreference: ' + ((e&&e.message)?e.message:String(e)), 'error'); }catch(_){ } }
  try { applyMockFromUrl_(); } catch(e){ try{ toast('Init', 'applyMockFromUrl: ' + ((e&&e.message)?e.message:String(e)), 'error'); }catch(_){ } }
  try { __forceRealFromUrl_(); } catch(e){ try{ toast('Init', '__forceRealFromUrl: ' + ((e&&e.message)?e.message:String(e)), 'error'); }catch(_){ } }

  // UI primero (blindado)
  try { initNav(); } catch(e){ try{ toast('Init', 'initNav: ' + ((e&&e.message)?e.message:String(e)), 'error'); }catch(_){ } }
  try { initListTabs(); } catch(e){ try{ toast('Init', 'initListTabs: ' + ((e&&e.message)?e.message:String(e)), 'error'); }catch(_){ } }
  try { updateMockChip_(); } catch(e){ }

  // estado inicial
  try { showScreen('screen-home'); } catch(e){ }
  try { setNavActive('home'); } catch(e){ }

  // toast diagnóstico
  try { toast('Init', 'OK · mode=' + (state && state.useMock ? 'mock' : 'real'), 'info'); } catch(_){ }

  // Router URL (hash)
  try{
    window.addEventListener('hashchange', () => {
      try{ __applyRouteFromHash__(); }catch(_){ }
    });
  }catch(_){ }

  try{ __applyRouteFromHash__(); }catch(_){ }

  // dashboard al final y protegido
  try { loadDashboard(); } catch(e){ try{ toast('Dashboard', (e && e.message) ? e.message : String(e), 'error'); }catch(_){ } }
});



